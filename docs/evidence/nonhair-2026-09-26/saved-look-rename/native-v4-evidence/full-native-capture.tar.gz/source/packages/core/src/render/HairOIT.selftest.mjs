/**
 * Gate for `render/HairOIT.js` — punch-list 3.6.
 *
 * Two halves, and this file says which is which because they are worth very different amounts.
 *
 * The WEAK HALF is arithmetic. It re-derives McGuire & Bavoil's equations (10) and (11) from the
 * primary artefact's own numbers, checks the two fixed points that catch the sign trap in (11), and
 * asserts that the `BlendMode` objects handed to the pass MRT carry exactly Listing 4's factors.
 * Every one of those, broken, produces a plausible picture rather than an obvious failure — a
 * weight function pinned at its clamp is a milky groom, and a wrong `blendDstAlpha` is a groom that
 * is merely a bit too solid.
 *
 * The STRONG HALF renders the real groom on a real GPU and measures the defect ITSELF rather than a
 * proxy for it.
 *
 *   ORDER DEPENDENCE  The same frame, twice, with the groom's triangle order reversed
 *                     (`?cardorder=reverse`). Nothing about the geometry, the camera, the lights or
 *                     the shading differs — only the sequence fragments arrive in. Order
 *                     independence IS the property that the two plates are the same picture, so the
 *                     RMS between them is the artefact in code values, with no reference render and
 *                     no judgement anywhere in it. A THIRD plate per arm — the same url loaded
 *                     again — is the instrument's own floor, and A3 bounds it against the smallest measured signal, so
 *                     the residue can be read as a count instead of through a visibility threshold.
 *
 *   MOTION            A still frame cannot show popping. The camera orbits 0.25 degrees per
 *                     simulated frame — small enough that the honest frame-to-frame change is a
 *                     fraction of a pixel — and the per-pixel temporal sigma over the hair band is
 *                     accumulated across twenty converged frames.
 *
 *   SEED DEPENDENCE   Punch-list 3.21, and the same instrument one axis over. The same converged
 *                     PORTRAIT frame, twice, with the coverage dither started at two disjoint
 *                     places in its own sequence (`material.hairDitherPhase`). A coverage that has
 *                     been integrated is a function of the coverage and the two plates agree; a
 *                     pattern that has only been reprojected is a function of the seed and they do
 *                     not. On `alive.html`, because the thing that integrates it is the shipped
 *                     TAAU resolve and the defect is invisible at full-body distance.
 *
 *   RED PROOF         🚩 `?oitdefect=material-blend` moves the two OIT blend modes from the pass MRT
 *                     onto `material.mrtNode`, which is where a reader of `docs/research/hair.md`
 *                     §4.3(a) would expect them to belong. `WebGPUPipelineUtils.js:132` reads
 *                     `renderObject.context.mrt`, which is the PASS's, so the material's table is
 *                     never consulted, the accumulation attachments get no blending at all, and the
 *                     sums become last-write-wins. The gate requires the `wboit` arm to go back to
 *                     being order dependent under the defect: a gate that has never failed is
 *                     decorative, and this one fails by 329x.
 *
 *                     🚩 AND 3.21's, WHICH IS A SOURCE BREAK AND WAS RUN THIS SESSION. Deleting
 *                     `.add( offset )` from `hairDitherThresholdNode` — the whole of the fix, one
 *                     term — takes C2 from 3.80x to 0.00x and C3 from 1.38x to 0.00x, both red;
 *                     restoring the file (verified by sha256 against a copy taken before the break)
 *                     turns both green again. ⚠️ C1 stayed GREEN under that break, at 0.0003 cv,
 *                     and that is
 *                     recorded rather than tidied away: a seed nothing reads makes both observers
 *                     agree exactly, which is LEARNINGS §1.25g, and it is why C2 is the liveness
 *                     control and not a nice-to-have.
 *
 * A measurement outside its range is a FAIL and exits non-zero. It is not grounds for widening the
 * range.
 *
 * ⚠️ **This gate does NOT enforce a GPU cost.** The cost numbers that decide 3.6 are in
 * `HairOIT.js`'s header and in the punch-list entry; a millisecond threshold asserted here would go
 * red on a slower machine and tell the next agent nothing about the code. What IS asserted is the
 * thing a cost number cannot be argued out of — which arms are correct.
 *
 * Usage:  node "packages/core/src/render/HairOIT.selftest.mjs"
 */

import path from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

import * as probe from './MotionProbe.mjs';

// 🚩 `fileURLToPath` and not string surgery on `import.meta.url`: this repository's path carries a
// space and a non-ASCII character, and a percent-encoded href handed to `fs` is a file that does
// not exist. `MotionProbe.mjs` reaches for `png.mjs` the same way and for the same reason.
const REPOSITORY_ROOT = path.resolve( path.dirname( fileURLToPath( import.meta.url ) ), '..', '..', '..', '..' );

const { decodePng } = await import(
    pathToFileURL( path.join( REPOSITORY_ROOT, 'tools', 'critic', 'png.mjs' ) ).href );

import {
    HAIR_DITHER_GOLDEN_STEP,
    HAIR_OIT_DEFAULT_MODE,
    HAIR_OIT_MODES,
    HAIR_WEIGHT_CEILING,
    HAIR_WEIGHT_FLOOR,
    HAIR_WEIGHT_RANGE,
    clipDepthValue,
    hairAccumBlendMode,
    hairDitherOffsetValue,
    hairWeightBlendMode,
    hairWeightValue,
    publishedWeightValue,
    viewDepthExtent
} from './HairOIT.js';

import {
    AddEquation,
    Box3,
    CustomBlending,
    OneFactor,
    OneMinusSrcAlphaFactor,
    PerspectiveCamera,
    Vector3,
    ZeroFactor
} from 'three/webgpu';

let checks = 0;
let failures = 0;

function report( name, passed, detail ) {

    checks += 1;
    if ( passed !== true ) failures += 1;
    console.log( `${ passed ? 'PASS' : 'FAIL' }  ${ name }\n      ${ detail }` );

}

// ---------------------------------------------------------------------------------------------
// The weak half — arithmetic
// ---------------------------------------------------------------------------------------------

console.log( '\n--- equation (11) and the sign convention that decides it ---------------------\n' );

{
    // The two fixed points. A perspective depth is 0 at the near plane and 1 at the far plane, and
    // the ONLY way to get both out of the paper's formula is to treat `z_near` and `z_far` as
    // negative alongside `z` — page 129, one line under the equation. Pass them positive and the
    // near plane reads 2.005, the cubic in equation (10) goes negative, and every fragment pins at
    // the clamp floor. That reads as "weighted-blended OIT is milky", which is a conclusion about
    // the method rather than about the transcription.
    const NEAR = 0.05;
    const FAR = 20;

    const atNear = clipDepthValue( NEAR, NEAR, FAR );
    const atFar = clipDepthValue( FAR, NEAR, FAR );

    report(
        'd(near) = 0 and d(far) = 1 exactly, which is what catches the sign trap in (11)',
        Math.abs( atNear ) < 1e-9 && Math.abs( atFar - 1 ) < 1e-9,
        `d(${ NEAR }) = ${ atNear.toExponential( 2 ) }, d(${ FAR }) = ${ atFar.toFixed( 12 ) }. ` +
            'With positive near/far the same call returns 2.005 at the near plane.'
    );

    // Monotone and inside the unit interval across the whole frustum — the property that makes it
    // a depth at all.
    const samples = [ 0.05, 0.1, 0.3, 0.75, 2, 8, 20 ].map( ( z ) => clipDepthValue( z, NEAR, FAR ) );
    let monotone = true;

    for ( let i = 1; i < samples.length; i ++ ) if ( samples[ i ] <= samples[ i - 1 ] ) monotone = false;

    report(
        'the depth is monotone and inside 0..1 across the whole frustum',
        monotone && samples.every( ( d ) => d >= 0 && d <= 1 ),
        samples.map( ( d ) => d.toFixed( 4 ) ).join( ' -> ' )
    );

}

console.log( '\n--- equation (10) over a groom, which is why the weight is re-fitted ------------\n' );

{
    // The groom's own slab, measured off the exported GLB by the round that built it and re-stated
    // here as the interval this arm captures at: a head at 0.66 m orbit radius spans roughly
    // 0.55–0.85 m in front of the camera.
    const FRONT = 0.55;
    const BACK = 0.85;

    const FRUSTUMS = [
        { near: 0.05, far: 20 },      // the hair arm's own camera
        { near: 0.05, far: 100 },
        { near: 0.1, far: 12 },       // src/stage.html's default
        { near: 0.01, far: 100 }      // alive.html's
    ];

    const rows = FRUSTUMS.map( ( { near, far } ) => {

        const front = publishedWeightValue( FRONT, 1, near, far );
        const back = publishedWeightValue( BACK, 1, near, far );

        return { near, far, front, back, ratio: front / back, backAtFloor: back <= HAIR_WEIGHT_FLOOR * ( 1 + 1e-9 ) };

    } );

    for ( const row of rows ) {

        console.log( `      near ${ String( row.near ).padEnd( 5 ) } far ${ String( row.far ).padEnd( 4 ) } ` +
            `front ${ row.front.toFixed( 5 ).padStart( 9 ) }  back ${ row.back.toFixed( 5 ).padStart( 9 ) }  ` +
            `ratio ${ row.ratio.toFixed( 3 ) }${ row.backAtFloor ? '   back AT THE CLAMP FLOOR' : '' }` );

    }

    // The claim the re-fit rests on: the published curve does not discriminate enough over a groom.
    // Stated as an upper bound rather than as an equality, because it is the DIRECTION that matters
    // and a three.js or paper revision could move the digits.
    const worstRatio = Math.max( ...rows.map( ( row ) => row.ratio ) );

    report(
        'the published equation (10) separates the front and back of a groom by under 5x',
        worstRatio < 5,
        `best of four frustums is ${ worstRatio.toFixed( 3 ) }x, against the ` +
            `${ HAIR_WEIGHT_RANGE }x the slab fit is authored at. A groom stacks 10-50 cards.`
    );

    // And the reason it cannot simply be tuned: the answer depends on the CAMERA and not on the
    // hair. Two frustums that differ only in their near plane — a change with no visual meaning —
    // move the absolute weight by more than two orders of magnitude, and one of them puts the back
    // of the groom on the clamp floor.
    const absolutes = rows.map( ( row ) => row.front );
    const spread = Math.max( ...absolutes ) / Math.min( ...absolutes );

    report(
        'and equation (10) is a property of the frustum, not of the groom — the whole case for the re-fit',
        spread > 100 && rows.some( ( row ) => row.backAtFloor ),
        `the same fragment at 0.55 m is worth ${ Math.min( ...absolutes ).toFixed( 5 ) } to ` +
            `${ Math.max( ...absolutes ).toFixed( 5 ) } across four frustums — ${ spread.toFixed( 0 ) }x — ` +
            `and near 0.01 pins the back of the groom at the ${ HAIR_WEIGHT_FLOOR } floor.`
    );

}

console.log( '\n--- the slab weight -------------------------------------------------------------\n' );

{
    // The two ends, exactly. `range` at the front and 1 at the back is the contract the composite
    // divides by, and an off-by-one here is a groom that is uniformly slightly wrong.
    const front = hairWeightValue( 0, 1, 64 );
    const back = hairWeightValue( 1, 1, 64 );

    report(
        'the slab weight spans exactly `range` at the front to 1 at the back',
        Math.abs( front - 64 ) < 1e-9 && Math.abs( back - 1 ) < 1e-9,
        `w(t=0) = ${ front.toFixed( 6 ) }, w(t=1) = ${ back.toFixed( 6 ) }`
    );

    // Monotone, and clamped outside the slab rather than extrapolated: a flyaway in front of the
    // bounding box must be worth the front weight and not `range x 8`.
    let monotone = true;
    let previous = Infinity;

    for ( const t of [ - 0.5, 0, 0.2, 0.4, 0.6, 0.8, 1, 1.5 ] ) {

        const value = hairWeightValue( t, 1 );
        if ( value > previous + 1e-12 ) monotone = false;
        previous = value;

    }

    report(
        'it is monotone in depth and clamped outside the slab in both directions',
        monotone
            && hairWeightValue( - 0.5, 1 ) === hairWeightValue( 0, 1 )
            && hairWeightValue( 1.5, 1 ) === hairWeightValue( 1, 1 ),
        `t = -0.5 gives ${ hairWeightValue( - 0.5, 1 ).toFixed( 4 ) } (same as t = 0), ` +
            `t = 1.5 gives ${ hairWeightValue( 1.5, 1 ).toFixed( 4 ) } (same as t = 1)`
    );

    // ⚠️ α is INSIDE w, as equations (7)-(10) write it. The accumulation then carries α twice — once
    // through the premultiplied colour and once through w — and the quotient is still a weighted
    // average. Hoisting α out to "simplify" is the plausible-looking mistake, and this is the check
    // that would catch it.
    report(
        'alpha is a linear factor of the weight, as equations (7)-(10) write it',
        Math.abs( hairWeightValue( 0.3, 0.25 ) - 0.25 * hairWeightValue( 0.3, 1 ) ) < 1e-12,
        `w(0.3, 0.25) = ${ hairWeightValue( 0.3, 0.25 ).toFixed( 6 ) } = ` +
            `0.25 x ${ hairWeightValue( 0.3, 1 ).toFixed( 6 ) }`
    );

    // The paper's clamps, which exist for 16-bit float underflow and overflow and not for looks.
    const enormous = hairWeightValue( 0, 1, 1e9 );
    const tiny = hairWeightValue( 1, 1e-9 );

    // ⚠️ The floor bounds the CURVE and not the product — `w(z,α) = α · max(1e-2, …)`, with α
    // outside the max. So a vanishing coverage really does produce a vanishing weight, and a first
    // draft of this check asserted the opposite (that 1e-9 of coverage would be lifted to 1e-10 by
    // the floor) and went red. The paper's floor exists to stop the DEPTH term underflowing, which
    // is a different hazard from a fragment that is genuinely almost absent.
    report(
        "the paper's clamps bound the depth curve, and alpha passes through them untouched",
        enormous === HAIR_WEIGHT_CEILING && Math.abs( tiny - 1e-9 ) < 1e-21,
        `range 1e9 at the front saturates to ${ enormous }, and an alpha of 1e-9 at the back gives ` +
            `${ tiny.toExponential( 2 ) } — alpha times the curve's own minimum of 1, not lifted to ` +
            `the ${ HAIR_WEIGHT_FLOOR } floor.`
    );

}

console.log( '\n--- Listing 4, factor by factor -------------------------------------------------\n' );

{
    const accum = hairAccumBlendMode();
    const weight = hairWeightBlendMode();

    // glBlendFuncSeparate(GL_ONE, GL_ONE, GL_ZERO, GL_ONE_MINUS_SRC_ALPHA)
    report(
        'the accumulation blend is Listing 4 exactly: ONE/ONE for rgb, ZERO/ONE_MINUS_SRC_ALPHA for a',
        accum.blending === CustomBlending
            && accum.blendSrc === OneFactor && accum.blendDst === OneFactor
            && accum.blendSrcAlpha === ZeroFactor && accum.blendDstAlpha === OneMinusSrcAlphaFactor
            && accum.blendEquation === AddEquation && accum.blendEquationAlpha === AddEquation,
        `src/dst ${ accum.blendSrc }/${ accum.blendDst }, srcA/dstA ${ accum.blendSrcAlpha }/${ accum.blendDstAlpha }. ` +
            'The alpha half is what turns three\'s fixed (0,0,0,1) clear into the revealage product, ' +
            'and it is the reason Listing 4 is buildable here and Listing 3 is not.'
    );

    report(
        'the weight blend is pure additive, and carries no separate alpha to get wrong',
        weight.blending === CustomBlending
            && weight.blendSrc === OneFactor && weight.blendDst === OneFactor
            && weight.blendSrcAlpha === null && weight.blendDstAlpha === null,
        `src/dst ${ weight.blendSrc }/${ weight.blendDst }, srcA/dstA ${ weight.blendSrcAlpha }/${ weight.blendDstAlpha }`
    );

    // Fresh objects per call. A shared `BlendMode` is stored by reference on the MRT node, so a
    // caller that mutated one would silently change every pass that had ever asked for it.
    report(
        'each call returns a fresh BlendMode, because the MRT node stores it by reference',
        hairAccumBlendMode() !== accum && hairWeightBlendMode() !== weight,
        'two calls, two objects'
    );

    // The revealage recurrence, run on the CPU over a stack of cards. This is the arithmetic the
    // alpha blend performs, and it is checked here because a wrong factor produces a groom that is
    // merely a little too solid — nobody would look at it and see a bug.
    const coverages = [ 0.42, 0.18, 0.65, 0.07, 0.31 ];
    let revealage = 1;                      // three's fixed clear for attachment i > 0

    for ( const alpha of coverages ) revealage = revealage * ( 1 - alpha );

    const expected = coverages.reduce( ( product, alpha ) => product * ( 1 - alpha ), 1 );

    // The literal is the real check and the reduction beside it is only a spelling of the loop, so
    // the literal is what caught a hand-derived 0.1177 in the first draft of this file. Keep both.
    //
    // ⚠️ THE TOLERANCE ON THE LITERAL IS ITS OWN LAST PLACE AND NOT A CHOSEN NUMBER. `0.106817` is
    // written to six decimals, so a correct implementation can sit at most half a unit in that last
    // place away from it — 5e-7. It was 5e-6 and the sweep this round found it breaking at the
    // measured 3.82e-7, a ratio of 13x, which is a tolerance ten times looser than the digits it is
    // checking justify. Tightened to what the literal says rather than to what the run reads.
    report(
        'the alpha recurrence dst.a <- dst.a x (1 - src.a) from a clear of 1 is the revealage product',
        Math.abs( revealage - expected ) < 1e-12 && Math.abs( revealage - 0.106817 ) < 5e-7,
        `five cards of coverage ${ coverages.join( ', ' ) } leave ${ revealage.toFixed( 6 ) } of the ` +
            'background showing, so the composite mixes 89.3% hair over 10.7% face.'
    );

}

console.log( '\n--- the dither sequence, which is 3.21 in arithmetic -----------------------------\n' );

{
    // D1 — the offset is a unit fraction and the sequence does not repeat. A sequence that closed
    // would stop improving the estimate at its period and the grain would come back, which is the
    // exact defect 3.21 removes, arriving later.
    const offsets = Array.from( { length: 4096 }, ( unused, frame ) => hairDitherOffsetValue( frame ) );
    const inRange = offsets.every( ( value ) => value >= 0 && value < 1 );
    const distinct = new Set( offsets.map( ( value ) => value.toFixed( 12 ) ) ).size;

    report(
        'D1 the offset is a unit fraction and 4096 frames give 4096 distinct values',
        inRange && distinct === offsets.length,
        `${ distinct } distinct of ${ offsets.length }, all in [0,1). A rational step of p/q would ` +
            'give exactly q, and the estimate would stop converging there.'
    );

    // D2 — THE PROPERTY THE STEP IS CHOSEN FOR, and the one a "does the offset move?" check misses.
    // By the three-distance theorem an additive recurrence at φ⁻¹ leaves at most three distinct gap
    // lengths and the largest is bounded by φ/N; white noise's largest gap is O(log N / N) and in
    // practice several times worse. This is what decides whether a temporal resolve given N frames
    // gets an O(1/N) estimate or an O(1/√N) one.
    const largestGap = ( sequence ) => {

        const sorted = [ ...sequence ].sort( ( a, b ) => a - b );
        let gap = sorted[ 0 ] + ( 1 - sorted[ sorted.length - 1 ] );

        for ( let i = 1; i < sorted.length; i ++ ) gap = Math.max( gap, sorted[ i ] - sorted[ i - 1 ] );

        return gap;

    };

    const goldenGaps = [ 16, 64, 256 ].map( ( n ) => ( {
        n, gap: largestGap( Array.from( { length: n }, ( u, f ) => hairDitherOffsetValue( f ) ) ) } ) );
    const whiteGaps = [ 16, 64, 256 ].map( ( n ) => ( {
        n, gap: largestGap( Array.from( { length: n }, ( u, f ) => hairDitherOffsetValue( f, 0, 'white-dither' ) ) ) } ) );

    for ( let i = 0; i < goldenGaps.length; i ++ ) {

        console.log( `      ${ String( goldenGaps[ i ].n ).padStart( 4 ) } frames   golden largest gap ` +
            `${ goldenGaps[ i ].gap.toFixed( 5 ) }   against phi/N = ${ ( 1.6180339887 / goldenGaps[ i ].n ).toFixed( 5 ) }   ` +
            `white ${ whiteGaps[ i ].gap.toFixed( 5 ) }   ratio ${ ( whiteGaps[ i ].gap / goldenGaps[ i ].gap ).toFixed( 2 ) }x` );

    }

    report(
        'D2 the golden step meets the three-distance bound phi/N at every N, and white noise does not',
        goldenGaps.every( ( row ) => row.gap <= 1.6180339888 / row.n + 1e-12 )
            && whiteGaps.every( ( row, i ) => row.gap > 1.5 * goldenGaps[ i ].gap ),
        `largest gap after 256 frames: golden ${ goldenGaps[ 2 ].gap.toFixed( 5 ) }, white ` +
            `${ whiteGaps[ 2 ].gap.toFixed( 5 ) }. 🚩 THIS IS THE CHECK ?white-dither EXISTS FOR — ` +
            'white noise moves every frame too, so a gate that only asserted movement is green on it.'
    );

    // D3 — the frozen defect must be frozen AND must still answer the phase. LEARNINGS §1.25g: a
    // value pinned to a CONSTANT makes two observers agree exactly, so a defect that ignored the
    // phase would sail through the rendered clause below by rendering the same plate twice.
    const frozen = Array.from( { length: 32 }, ( u, f ) => hairDitherOffsetValue( f, 0, 'frozen-dither' ) );
    const frozenElsewhere = hairDitherOffsetValue( 0, 977, 'frozen-dither' );

    // ⚠️ THE SECOND HALF USED TO READ `> 0.05` AND THE SWEEP FOUND IT BREAKING AT 0.819 — 16x away,
    // with nothing in the file approaching it from the other side. The 0.05 was never derived: what
    // has to be true is that the two phases the RENDERED clause uses give different fields, and
    // `frozen-dither` maps phase through the same golden sequence D2 has already bounded. So the
    // clause now asserts the property instead of a distance — the phases are distinct, and 16 of
    // them meet the same three-distance bound, which is stronger than any single gap and carries no
    // number this file chose.
    const frozenPhases = Array.from( { length: 16 }, ( u, phase ) =>
        hairDitherOffsetValue( 0, phase, 'frozen-dither' ) );
    const frozenSorted = [ ...frozenPhases ].sort( ( a, b ) => a - b );
    let frozenGap = frozenSorted[ 0 ] + ( 1 - frozenSorted[ frozenSorted.length - 1 ] );

    for ( let i = 1; i < frozenSorted.length; i ++ ) {

        frozenGap = Math.max( frozenGap, frozenSorted[ i ] - frozenSorted[ i - 1 ] );

    }

    report(
        'D3 frozen-dither does not advance with the frame, and DOES answer the phase',
        new Set( frozen ).size === 1
            && frozenElsewhere !== frozen[ 0 ]
            && new Set( frozenPhases ).size === frozenPhases.length
            && frozenGap <= 1.6180339888 / frozenPhases.length + 1e-12,
        `32 frames give one value (${ frozen[ 0 ].toFixed( 6 ) }) and phase 977 gives ` +
            `${ frozenElsewhere.toFixed( 6 ) }; 16 phases give 16 distinct fields whose largest gap ` +
            `is ${ frozenGap.toFixed( 5 ) } against phi/16 = ${ ( 1.6180339887 / 16 ).toFixed( 5 ) }. ` +
            'Without the second half the red proof below would compare a plate against itself and go ' +
            'green on the defect — and a defect that answered the phase with a near-constant would ' +
            'pass a distance test while still giving two observers nearly the same picture.'
    );

    report(
        'D3b the shipped arm is the stochastic one and the step is the golden-ratio conjugate',
        HAIR_OIT_DEFAULT_MODE === 'stochastic'
            && Math.abs( HAIR_DITHER_GOLDEN_STEP * HAIR_DITHER_GOLDEN_STEP + HAIR_DITHER_GOLDEN_STEP - 1 ) < 1e-15,
        `default '${ HAIR_OIT_DEFAULT_MODE }', step ${ HAIR_DITHER_GOLDEN_STEP } — and phi^-2 + phi^-1 = 1 ` +
            `holds to ${ Math.abs( HAIR_DITHER_GOLDEN_STEP ** 2 + HAIR_DITHER_GOLDEN_STEP - 1 ).toExponential( 1 ) }, ` +
            'which is the defining equation and catches a mistyped digit.'
    );

}

console.log( '\n--- the slab, in view space -----------------------------------------------------\n' );

{
    // A world-axis-aligned box is NOT view-axis-aligned, and taking its z extent directly
    // under-reports the slab at every angle except dead-on. That is every frame of the orbit this
    // item is gated on, so it is worth a known-answer check rather than a reading.
    const camera = new PerspectiveCamera( 32, 1, 0.05, 20 );
    const bounds = new Box3( new Vector3( - 0.1, - 0.1, - 0.1 ), new Vector3( 0.1, 0.1, 0.1 ) );
    const scratch = new Vector3();

    // Dead-on at 1 m: the slab is exactly the box's own depth, 0.9 to 1.1.
    camera.position.set( 0, 0, 1 );
    camera.lookAt( 0, 0, 0 );
    camera.updateMatrixWorld( true );
    camera.matrixWorldInverse.copy( camera.matrixWorld ).invert();

    const straight = viewDepthExtent( bounds, camera, scratch );

    // At 45 degrees the far corner is sqrt(2) x 0.1 further away, so the slab is wider by exactly
    // that — the quantity a naive world-space z extent would miss.
    camera.position.set( Math.SQRT1_2, 0, Math.SQRT1_2 );
    camera.lookAt( 0, 0, 0 );
    camera.updateMatrixWorld( true );
    camera.matrixWorldInverse.copy( camera.matrixWorld ).invert();

    const diagonal = viewDepthExtent( bounds, camera, scratch );

    report(
        'the view-space slab is exact dead-on and widens by sqrt(2) at 45 degrees',
        Math.abs( straight.near - 0.9 ) < 1e-6 && Math.abs( straight.far - 1.1 ) < 1e-6
            && Math.abs( ( diagonal.far - diagonal.near ) - 0.2 * Math.SQRT2 ) < 1e-6,
        `dead-on ${ straight.near.toFixed( 4 ) }..${ straight.far.toFixed( 4 ) } (depth ` +
            `${ ( straight.far - straight.near ).toFixed( 4 ) }), at 45 degrees depth ` +
            `${ ( diagonal.far - diagonal.near ).toFixed( 4 ) } against sqrt(2) x 0.2 = ` +
            `${ ( 0.2 * Math.SQRT2 ).toFixed( 4 ) }. A world-space z extent would report 0.2 at both.`
    );

}

// ---------------------------------------------------------------------------------------------
// The strong half — the real groom on a real GPU
// ---------------------------------------------------------------------------------------------

const WIDTH = 560;
const HEIGHT = 700;

/**
 * The hair mass on the subject's right, at the arm's fixed 34-degree azimuth. Stated as a rect
 * rather than derived, and it is only used for the MOTION statistic — the order statistic below is
 * whole-frame precisely so that no rect has to be argued about.
 */
const HAIR_BAND = { x: 320, y: 110, width: 180, height: 350 };

/** Frames kept from the orbit clip. 40 warm-up steps is well past TAAU's 31-frame Halton period. */
const MOTION_FRAMES = 60;
const MOTION_KEEP = Array.from( { length: 20 }, ( unused, index ) => 41 + index );

/**
 * ## 🚩 ROUND 19: `CUTOUT_TIE_SHARE` IS GONE. A BOUND THAT COULD NOT BE PINNED WAS REMOVED RATHER
 * THAN RE-DERIVED, AND THE MEASUREMENT THAT SAYS SO IS BELOW
 *
 * Round 18 replaced `cutout.max <= 2` with a SHARE — `cutout.overTwoPercent <= 0.01` — and paired
 * it with a same-run liveness control, A3b, in which `blend` fails the same constant. An adversary
 * then set that constant to 5.0, five hundred times looser, and the whole file stayed green with
 * the liveness control included. **That refutation is correct and it generalises: a one-sided
 * bound paired with a liveness control on the SAME constant does not pin the constant. It only
 * says the constant lies somewhere between the shipped measurement and the defect measurement.**
 *
 * Both edges were measured this session BY MUTATION, on this file at sha256 `18849da6…`, each one a
 * full run of the gate:
 *
 *     bound 0.0004%   A3 FAILS   — the shipped groom measures 2 px of 392,000, i.e. 0.000510%
 *     bound 0.01%     both pass  — the shipped constant, 19.6x above the measurement
 *     bound 5.0%      both pass  — the adversary's value
 *     bound 40%       A3b FAILS  — `blend` measures 38.099%
 *
 * The pair admitted **every value across a 74,700x window** and the shipped constant sat near its
 * logarithmic middle. That is a classifier for a bimodal quantity dressed as a threshold on a
 * continuous one, and no value of it is defensible — including a tighter one, which would only be
 * the measurement plus a margin.
 *
 * ## What replaced it, and why there is no number left in it to pin
 *
 * Historical exact-zero calibration (superseded 2026-09-22 by measured noise intervals below). Two page
 * loads of the SAME arm at the SAME query differ in **0 pixels of 392,000** — zero by count, not
 * zero by a threshold — on all five arms, twice over. Every pixel the reversal moves is therefore
 * an order effect. That clause has no tolerance to loosen: its only other value is 1 px.
 *
 * 🎯 **AND "DIFFERS AT ALL" HAS RESOLUTION WHERE THE OVER-2 SHARE HAS NONE.** Measured this
 * session, whole frame, 560x700:
 *
 *     arm            differs at all      over 2 cv      RMS cv
 *     cutout               237 px            2 px       0.0161
 *     hash                 384 px            9 px       0.0245
 *     stochastic           517 px           16 px       0.0386
 *     wboit             20,223 px          396 px       0.1877
 *     blend            195,303 px      149,350 px      21.5900
 *
 * A share bound whose subject is 2 counts is a bound on nothing: one extra tie crosses it, which is
 * exactly the reading that killed `max <= 2` one round earlier for the same reason in a different
 * statistic. The ordering across the three MECHANISMS, however, is 39x and 10x apart, and it is a
 * relation between three arms of one run rather than a number anybody chose.
 *
 * ⚠️ **THE TIE SET IS FIXED FROM RUN TO RUN AND THE R18 HEADER SAID IT WAS NOT.** Two repeats of
 * the entire comparison this session came back bit-identical — 237 / 2 / 0.0161 / 2.7 both times,
 * on every arm. The R18 pair that differed (2 px and 2.213 from a probe, 3 px and 2.7 from the
 * gate) were different SITTINGS, which is the correction `HairShadow.selftest.mjs` had to make to
 * its own four-run agreement. Within one session this pipeline is deterministic.
 *
 * 🚩 **THE SHAPE CLAIM IN A3's OLD TITLE WAS FALSE, AND IT IS NOT BEING CARRIED FORWARD.** It read
 * *"a depth test moves a countable set of tied pixels, an fp16 sum moves an AREA"*. Measured, as
 * 4-connected components of each arm's differing set:
 *
 *     cutout      237 px in   127 components, largest      74, mean 1.87 px, 1.283 4-neighbours
 *     wboit    20,223 px in 9,703 components, largest     408, mean 2.08 px, 1.316 4-neighbours
 *     blend   195,303 px in 1,498 components, largest 191,924, mean  130 px, 3.874 4-neighbours
 *
 * `wboit`'s residue has the SAME shape as `cutout`'s — scattered specks two pixels wide — and only
 * `blend` is an area. The two arms differ in COUNT by 85x and in shape not at all, so a clause
 * written on component structure would have gone green over the defect. It is recorded because it
 * is the fix this round reached for first, and a negative result is a result.
 *
 * ## What the new clauses are worth, and what was given up
 *
 * ⚠️ **A3b IS WEAKER THAN THE OLD BOUND IN A BAND, AND THAT IS THE TRADE.** A defect that took the
 * cutout arm from 237 px to, say, 5,000 px would have crossed 0.01% and does not cross the
 * ordering. What is bought for it is that nothing in the clause can be loosened by an adversary:
 * there is no constant. The band is not empty and the next round should know it is there.
 *
 * 🚩 THE SOURCE-LEVEL RED PROOF IS UNCHANGED IN KIND AND WAS RE-RUN THIS ROUND AGAINST THE NEW
 * CLAUSES — `material.depthWrite = false` added to `configureHairMaterial`'s `cutout` branch, one
 * line, the arm keeping its `alphaTest` and losing only the depth resolution the deduction rests
 * on. `HairOIT.js` restored afterwards to sha256
 * `9fa71467a1e2fd576ad6d28dda36bc92ff9ec8161670028729c44a5d3d895533`, the digest it had before the
 * break, verified by `shasum` and not by eye:
 *
 *     BROKEN    cutout 21.8138 cv RMS, 179,265 px differ at all — past wboit's 20,223
 *               FAIL A2 (cutout), FAIL A3b.  FAIL: 30/32
 *     RESTORED  cutout 0.0161 cv RMS, 237 px differ at all.  PASS: 32/32
 *
 * ⚠️ **A3 STAYS GREEN UNDER THAT BREAK AND IT IS MEANT TO** — the same-url floor is still 0 px on
 * every arm, because the break changes what the reversal does and not whether the renderer repeats
 * itself. That is the R18 note about A3b staying green, kept and made true of the clause it now
 * describes: A3 is a control on the INSTRUMENT, and the only thing that can make it red is the
 * instrument.
 */

console.log( '\n--- draw-order dependence, which is the defect itself ---------------------------\n' );

let server = null;
let browser = null;

const order = {};
const floor = {};
const motion = {};

try {

    server = await probe.startProbeServer( { port: 5189 } );
    browser = await probe.launchProbeBrowser();

    const plate = async ( query, frames, keep ) => {

        const shot = await probe.capturePlates( {
            browser, baseUrl: server.baseUrl, page: '/src/stage.html',
            query, width: WIDTH, height: HEIGHT, frames, keep, stepSeconds: 1 / 60
        } );

        if ( shot.errors.length > 0 ) throw new Error( `${ query }: ${ shot.errors.slice( 0, 2 ).join( ' | ' ) }` );

        return keep.map( ( index ) => shot.frames.get( index ) );

    };

    const ARMS = [ ...HAIR_OIT_MODES, 'defect' ];

    for ( const arm of ARMS ) {

        const suffix = arm === 'defect' ? 'wboit&oitdefect=material-blend' : arm;
        const still = `?hair=1&bare&oit=${ suffix }&orbit=0&w=${ WIDTH }&h=${ HEIGHT }`;

        const [ forward ] = await plate( still, 40, [ 40 ] );
        const [ reverse ] = await plate( `${ still }&cardorder=reverse`, 40, [ 40 ] );

        order[ arm ] = frameDifference( forward, reverse );

        // The motion clip is only worth taking for the four real arms; the defect exists to fail the
        // order check and nothing else.
        if ( arm !== 'defect' ) {

            // THE INSTRUMENT'S OWN FLOOR, and it is a third plate rather than an argument: the same
            // url, loaded again, stepped again. A3 requires it to be resolved below the compared signals, which is what
            // licenses reading the reversal's residue as an order effect down to the last pixel.
            const [ again ] = await plate( still, 40, [ 40 ] );

            floor[ arm ] = frameDifference( forward, again );

            const clip = await plate(
                `?hair=1&bare&oit=${ suffix }&orbit=0.25&w=${ WIDTH }&h=${ HEIGHT }`,
                MOTION_FRAMES, MOTION_KEEP
            );

            motion[ arm ] = clipStatistics( clip, HAIR_BAND );

        }

    }

} catch ( error ) {

    report( 'the groom came up on a real GPU', false, `it did not: ${ error.message }` );

}

if ( order.blend !== undefined && order.wboit !== undefined ) {

    for ( const [ arm, value ] of Object.entries( order ) ) {

        console.log( `      ${ arm.padEnd( 8 ) } rms ${ value.rms.toFixed( 4 ).padStart( 9 ) } cv   ` +
            `worst pixel ${ value.max.toFixed( 1 ).padStart( 6 ) } cv   ` +
            `${ String( value.differing ).padStart( 7 ) } px differ at all   ` +
            `${ value.overTwoPercent.toFixed( 3 ).padStart( 7 ) }% of pixels move by more than 2 cv   ` +
            `same-url floor ${ floor[ arm ] === undefined ? '  n/a' : String( floor[ arm ].differing ).padStart( 5 ) } px` );

    }

    // A1 — the defect exists. Without this the rest of the file measures nothing: if naive blending
    // were already order independent on this groom there would be no item.
    report(
        'A1 naive alpha blending IS order dependent on this groom, which is the whole of 3.6',
        order.blend.rms > 5 && order.blend.overTwoPercent > 5,
        `reversing the triangle order moves the frame by ${ order.blend.rms.toFixed( 4 ) } code values ` +
            `RMS, up to ${ order.blend.max.toFixed( 1 ) } on the worst pixel, with ` +
            `${ order.blend.overTwoPercent.toFixed( 3 ) }% of the frame moving by more than 2. Same ` +
            'geometry, same camera, same lights — only the sequence.'
    );

    // A2 — the three candidate arms are not. The ceiling is 1 code value: below that a difference
    // cannot survive 8-bit quantisation of the plate, so it is not a picture anybody can see.
    for ( const arm of [ 'cutout', 'hash', 'stochastic', 'wboit' ] ) {

        report(
            `A2 the ${ arm } arm is order INDEPENDENT — under 1 code value RMS`,
            order[ arm ].rms < 1,
            `${ order[ arm ].rms.toFixed( 4 ) } cv RMS against blend's ${ order.blend.rms.toFixed( 4 ) } — ` +
                `a ${ ( order.blend.rms / order[ arm ].rms ).toFixed( 0 ) }x reduction — with ` +
                `${ order[ arm ].overTwoPercent.toFixed( 3 ) }% of pixels over 2 cv.`
        );

    }

    // A reload can change a few quantised pixels even with a fixed scene. Measure that
    // noise floor and require a full decimal digit of signal separation, rather than
    // treating every nonzero difference as order dependence (REQ-085).
    const floorArms = Object.keys( floor );
    const minimumSignal = Math.min( ...floorArms.map( arm => order[ arm ].differing ) );
    const maximumNoise = Math.max( ...floorArms.map( arm => floor[ arm ].differing ) );
    const resolved = ( noise, signal ) => signal > 0 && noise * 10 < signal;
    report(
        'A3 the reload noise floor is below one tenth of the smallest order signal',
        resolved( maximumNoise, minimumSignal ),
        `${ maximumNoise } px maximum reload noise / ${ minimumSignal } px minimum signal; ` +
            floorArms.map( arm => `${ arm } ${ floor[ arm ].differing }` ).join( ', ' ) +
            '. These are measured counts with uncertainty, not exact order-effect counts.'
    );
    report(
        'A3 control: unresolved and absent signals are rejected, including the boundary',
        !resolved( 1, 0 ) && !resolved( 1, 10 ) && !resolved( 2, 10 ) && resolved( 1, 11 ),
        'Zero signal, equal uncertainty budget, and excessive noise fail; a separated signal passes.'
    );

    // A3b — THE SHAPE OF THE RESIDUE, AS AN ORDERING BETWEEN THREE MECHANISMS MEASURED IN ONE RUN.
    //
    // 🎯 THERE IS NO CONSTANT IN THIS CLAUSE, WHICH IS THE WHOLE OF ROUND 19'S CORRECTION TO IT.
    // The three arms differ in how demanding the coincidence is that lets draw order change a
    // pixel: `cutout`/`hash`/`stochastic` keep `depthWrite` and a coverage decision, so only an
    // EXACT depth tie between two admitted fragments can flip one; `wboit` sums in fp16, so any
    // pair whose ROUNDING differs flips one; `blend` accumulates in draw order, so any overlap at
    // all does. Those three populations are ordered by construction, and the clause asserts the
    // order rather than a threshold anybody chose. See the block above `HAIR_BAND` for the
    // 74,700x window the constant it replaces was free to sit anywhere in.
    const depthResolved = [ 'cutout', 'hash', 'stochastic' ];
    const worstDepthResolved = depthResolved.reduce(
        ( worst, arm ) => order[ arm ].differing > order[ worst ].differing ? arm : worst );

    report(
        'A3b the uncertainty intervals are ordered by how demanding their coincidence is: depth tie < fp16 ' +
            'rounding < any overlap',
        order[ worstDepthResolved ].differing + maximumNoise < order.wboit.differing - maximumNoise
            && order.wboit.differing + maximumNoise < order.blend.differing - maximumNoise,
        `worst depth-resolved arm is ${ worstDepthResolved } at ${ order[ worstDepthResolved ].differing } px ` +
            `of ${ WIDTH * HEIGHT }; wboit ${ order.wboit.differing } px ` +
            `(${ ( order.wboit.differing / Math.max( 1, order[ worstDepthResolved ].differing ) ).toFixed( 0 ) }x); ` +
            `blend ${ order.blend.differing } px ` +
            `(${ ( order.blend.differing / Math.max( 1, order.wboit.differing ) ).toFixed( 0 ) }x). ` +
            'cutout ' + order.cutout.differing + ', hash ' + order.hash.differing + ', stochastic ' +
            order.stochastic.differing + '. 🚩 Under the source break — `material.depthWrite = false` ' +
            'in configureHairMaterial\'s cutout branch — the cutout arm crosses wboit and this clause ' +
            'goes red; the readings are in the block above `HAIR_BAND`.'
    );

    // A3c — and the fp16 arm's residue is REAL and is not a wash. Two bounds rather than none,
    // because "wboit moves more pixels than a depth test does" is satisfied by an arm that moves a
    // lot of invisible ones. `max > 2` uses the same 8-bit quantisation step A2's ceiling is
    // derived from rather than a third opinion.
    //
    // ⚠️ THE RECORDED RATIOS HERE WENT STALE UNDER THE R19 ATLAS REWRITE, which is the reason a
    // pinning ratio has to be re-measured rather than inherited. They read "16.3 cv (8.2x)" and
    // "0.101% (5.0x)"; re-measured this session on the strand atlas, `max` breaks at 8.1 cv (4.05x)
    // and the share breaks at 0.036% (13.9x). Neither bound moved and neither should.
    //
    // 🚩 HOW THOSE TWO BREAKING VALUES WERE OBTAINED, because it is not the same method the
    // HairDynamics budget was pinned by and the difference matters to anyone rechecking them: both
    // clauses compare a MEASURED SCALAR against a literal, so the breaking value is that scalar and
    // it is read off the run rather than found by moving the bound. No mutation run stands behind
    // the 4.05x and 13.9x. That is sound for a direct comparison and is NOT sound for a compound
    // condition — where a second term can dominate, only an actual mutation finds the real edge,
    // which is exactly how `RED PROOF 1` in `HairShadow.selftest.mjs` was found to be carrying a
    // dead `Math.max( 200, … )` literal in R19.
    //
    // 🎯 WHAT PINS THE SHARE IS A SEPARATION BETWEEN TWO ARMS IN THIS RUN, not its distance from
    // one of them. `blend` — the same statistic on the arm that has no order independence at all —
    // reads 36.140% against wboit's 0.036%, three orders of magnitude apart, and 0.5% sits inside
    // that gap nearer the green end. A bound between two measured states is pinned by the pair; the
    // 13.9x is what it costs to be on the safe side of a classifier, not slack to be tightened out.
    // LEARNINGS §1.25z — do not refit this onto 0.036%.
    report(
        'A3c the fp16 arm\'s residue is visible somewhere and is nowhere an area',
        order.wboit.max > 2 && order.wboit.overTwoPercent < 0.5,
        `wboit's worst pixel moves ${ order.wboit.max.toFixed( 1 ) } cv — above the 2 cv a plate can ` +
            `resolve — while only ${ order.wboit.overTwoPercent.toFixed( 3 ) }% of the frame moves that ` +
            `far, against blend's ${ order.blend.overTwoPercent.toFixed( 3 ) }%. Reassociation of a ` +
            'half-float sum, not a sorting artefact.'
    );

    // A4 — THE RED PROOF. The blend modes moved to the material, which is where they look like they
    // belong and where three never reads them.
    report(
        'A4 RED PROOF: with the blend modes on material.mrtNode the wboit arm is order dependent again',
        order.defect.rms > 5 && order.defect.rms > 50 * order.wboit.rms,
        `?oitdefect=material-blend takes the wboit arm from ${ order.wboit.rms.toFixed( 4 ) } cv RMS to ` +
            `${ order.defect.rms.toFixed( 4 ) } — ${ ( order.defect.rms / order.wboit.rms ).toFixed( 0 ) }x — ` +
            `with ${ order.defect.overTwoPercent.toFixed( 3 ) }% of the frame moving. ` +
            'WebGPUPipelineUtils reads renderObject.context.mrt, which is the PASS\'s; the material\'s ' +
            'table is never consulted and the attachments get no blending at all.'
    );

}

console.log( '\n--- under motion, because a still frame cannot show popping ----------------------\n' );

if ( motion.wboit !== undefined ) {

    for ( const [ arm, value ] of Object.entries( motion ) ) {

        console.log( `      ${ arm.padEnd( 8 ) } per-pixel sigma ${ value.sigma.toFixed( 4 ).padStart( 8 ) } cv   ` +
            `frame-to-frame rms median ${ value.median.toFixed( 4 ) } max ${ value.max.toFixed( 4 ) }   ` +
            `spike ${ ( value.max / value.median ).toFixed( 2 ) }x` );

    }

    // B1 — the accumulation arm is the most stable thing in the comparison. This is the measurement
    // that says WBOIT is worth having even though it is the one this project cannot afford: it is
    // the quality reference the cheap arms are judged against.
    const worstOther = Math.max( ...Object.entries( motion )
        .filter( ( [ arm ] ) => arm !== 'wboit' )
        .map( ( [ , value ] ) => value.sigma ) );

    report(
        'B1 wboit is the most temporally stable arm under a 0.25 deg/frame orbit',
        motion.wboit.sigma < worstOther,
        `per-pixel sigma over the hair band, 20 converged frames: wboit ${ motion.wboit.sigma.toFixed( 4 ) }, ` +
            `blend ${ motion.blend.sigma.toFixed( 4 ) }, hash ${ motion.hash.sigma.toFixed( 4 ) }, ` +
            `cutout ${ motion.cutout.sigma.toFixed( 4 ) } code values.`
    );

    // B2 — and the arm 3.6 originally implied, alpha testing, is the WORST. That is 3.12's finding
    // arriving on hair: a binary coverage decision on a card silhouette crawls, and the temporal
    // resolve cannot integrate what it is not given.
    report(
        'B2 the cutout arm is the LEAST stable, which is the silhouette crawling',
        motion.cutout.sigma > motion.hash.sigma && motion.cutout.sigma > motion.wboit.sigma,
        `cutout ${ motion.cutout.sigma.toFixed( 4 ) } against hash ${ motion.hash.sigma.toFixed( 4 ) } ` +
            `and wboit ${ motion.wboit.sigma.toFixed( 4 ) } — ` +
            `${ ( motion.cutout.sigma / motion.wboit.sigma ).toFixed( 2 ) }x the accumulation arm. ` +
            'A binary alpha test is the one decision a temporal filter cannot soften.'
    );

    // B3 — nothing POPS. A pop is a single frame that moves far more than its neighbours, so the
    // statistic is the ratio of the worst frame-to-frame step to the median one. An orbit at a
    // constant rate has a nearly constant honest step, so a large ratio is an artefact.
    const spikes = Object.entries( motion ).map( ( [ arm, value ] ) => ( { arm, ratio: value.max / value.median } ) );
    const worstSpike = spikes.reduce( ( worst, row ) => row.ratio > worst.ratio ? row : worst );

    report(
        'B3 no arm pops: the worst frame-to-frame step is within 2x of the median one',
        worstSpike.ratio < 2,
        `worst is ${ worstSpike.arm } at ${ worstSpike.ratio.toFixed( 2 ) }x — ` +
            spikes.map( ( row ) => `${ row.arm } ${ row.ratio.toFixed( 2 ) }x` ).join( ', ' ) +
            '. The camera moves at a constant rate, so a constant step is the honest answer and a ' +
            'spike would be a card changing places.'
    );

}

// ---------------------------------------------------------------------------------------------
// Punch-list 3.21 — the coverage decision, on the page a judge captures
// ---------------------------------------------------------------------------------------------

/**
 * ## 🎯 SEED DEPENDENCE, AND IT IS THE SAME INSTRUMENT AS THE ORDER CHECK ABOVE
 *
 * A1–A4 measure the defect they are about — draw-order dependence — by rendering the same frame
 * twice with only the order changed. This does the same thing one axis over. A stochastic alpha
 * test decides coverage by comparing it against a threshold field; if the temporal resolve has
 * INTEGRATED those decisions the picture is a function of the coverage, and starting the sequence
 * somewhere else must give the same picture. If the pattern has only been REPROJECTED the picture
 * is a function of the seed, and the RMS between the two plates is the dust, in code values, with
 * no reference render and no judgement anywhere in it.
 *
 * ⚠️ **It runs on `alive.html` and not on `stage.html`, and that is not a convenience.** The arm
 * only works if something integrates it, the thing that integrates it is the shipped TAAU resolve
 * at `resolutionScale` 0.66, and `stage.html`'s hair arm is a different framing at a different
 * scale against a groom-and-three-lights control. The defect is invisible at full-body distance —
 * which is exactly why it survived three rounds of gates — so the plate is the portrait.
 *
 * The two runs are separate page loads with the phase set before the first step, so the whole
 * convergence happens on one phase. The seed is driven through `material.hairDitherPhase` rather
 * than through a URL for the reason `HAIR_SHADOW_ALPHA_CUTOFF` gives: the handle already exists on
 * the material, and adding a URL key would put an eighth row on this page's toggle surface that
 * only this file ever reads.
 */
const DITHER_WIDTH = 900;
const DITHER_HEIGHT = 1200;

/** 128 steps of zero seconds — a frozen scene rendered again and again, so the resolve converges. */
const DITHER_FRAMES = 128;

/** Coprime with nothing in particular; large enough that the two sample sets do not overlap. */
const DITHER_PHASE = 977;

const dither = {};

if ( server !== null && browser !== null ) {

    try {

        const alivePlate = async ( { arm, phase, step, frames } ) => {

            const context = await browser.newContext( {
                viewport: { width: DITHER_WIDTH, height: DITHER_HEIGHT }, deviceScaleFactor: 1
            } );

            const page = await context.newPage();
            const errors = [];

            page.on( 'pageerror', ( error ) => errors.push( error.message ) );

            // `grain=0` because the grade's film grain is a per-frame random field that sits on
            // every arm equally and would swamp a statistic about the dither. `freeze` plus a zero
            // step is the only way to let a temporal filter converge on a scene that is not moving
            // — `MotionProbe`'s own `stepSeconds` note says why.
            const query = `?bare&freeze&seed=1&grain=0&hair=1&hairoit=${ arm }&capture`;

            await page.goto( `${ server.baseUrl }/alive.html${ query }`, { waitUntil: 'domcontentloaded' } );
            await page.waitForFunction( () => typeof globalThis.__SUGATA_STEP__ === 'function',
                null, { timeout: 180_000, polling: 200 } );

            await page.evaluate( ( [ wantedPhase, wantedStep ] ) => {

                const material = globalThis.sugata.session.hairMaterial;

                material.hairDitherPhase = wantedPhase;
                material.hairDitherStep = wantedStep;

            }, [ phase, step ] );

            for ( let i = 0; i < frames; i ++ ) await page.evaluate( () => globalThis.__SUGATA_STEP__( 0 ) );

            const shot = await page.screenshot();
            await context.close();

            if ( errors.length > 0 ) throw new Error( `${ arm }/${ step }: ${ errors.slice( 0, 2 ).join( ' | ' ) }` );

            return decodePlate(shot );

        };

        // The mask, measured once and applied to every case: every pixel the groom moves by more
        // than 2 code values against the same page with no groom on it. 🚩 STATED BECAUSE RULE 4
        // SAYS SO — it contains the groom AND what the groom changes around it (its cast shadow,
        // the card wash on the chest), and it contains no pixel the groom leaves alone, so a case
        // that chews its own silhouette cannot shrink its own denominator.
        const baldContext = await browser.newContext( {
            viewport: { width: DITHER_WIDTH, height: DITHER_HEIGHT }, deviceScaleFactor: 1
        } );

        const baldPage = await baldContext.newPage();

        await baldPage.goto( `${ server.baseUrl }/alive.html?bare&freeze&seed=1&grain=0&capture`,
            { waitUntil: 'domcontentloaded' } );
        await baldPage.waitForFunction( () => typeof globalThis.__SUGATA_STEP__ === 'function',
            null, { timeout: 180_000, polling: 200 } );

        for ( let i = 0; i < DITHER_FRAMES; i ++ ) await baldPage.evaluate( () => globalThis.__SUGATA_STEP__( 0 ) );

        const bald = decodePlate(await baldPage.screenshot() );
        await baldContext.close();

        const withGroom = await alivePlate( { arm: 'stochastic', phase: 0, step: null, frames: DITHER_FRAMES } );
        const groomMask = [];

        for ( let y = 0; y < DITHER_HEIGHT; y ++ ) {

            for ( let x = 0; x < DITHER_WIDTH; x ++ ) {

                if ( Math.abs( probe.codeValueAt( withGroom, x, y ) - probe.codeValueAt( bald, x, y ) ) > 2 ) {

                    groomMask.push( [ x, y ] );

                }

            }

        }

        console.log( `\n--- 3.21, the coverage decision: does the picture depend on the seed? -----------\n` );
        console.log( `      mask ${ groomMask.length } px of ${ DITHER_WIDTH * DITHER_HEIGHT } ` +
            `(${ ( 100 * groomMask.length / ( DITHER_WIDTH * DITHER_HEIGHT ) ).toFixed( 2 ) }%), ` +
            'every pixel the groom moves against the same page with no groom\n' );

        for ( const step of [ null, 'white-dither', 'frozen-dither' ] ) {

            const a = step === null ? withGroom : await alivePlate( { arm: 'stochastic', phase: 0, step, frames: DITHER_FRAMES } );
            const b = await alivePlate( { arm: 'stochastic', phase: DITHER_PHASE, step, frames: DITHER_FRAMES } );

            dither[ step ?? 'shipped' ] = maskedDifference( a, b, groomMask );

        }

        for ( const [ name, value ] of Object.entries( dither ) ) {

            console.log( `      ${ name.padEnd( 14 ) } seed RMS ${ value.rms.toFixed( 4 ).padStart( 8 ) } cv   ` +
                `worst ${ value.max.toFixed( 1 ).padStart( 6 ) }   ${ value.overTwoPercent.toFixed( 2 ).padStart( 6 ) }% over 2 cv` );

        }

    } catch ( error ) {

        report( '3.21 the portrait plate came up', false, `it did not: ${ error.message }` );

    }

}

if ( dither.shipped !== undefined ) {

    // C1 — the shipped arm's picture is mostly a function of the coverage rather than of the seed.
    // The bound is an absolute one because the quantity has a meaning: 8 code values RMS over the
    // groom is a visible dust cloud and 4 is not, and the arm measures 3.7534.
    report(
        'C1 the shipped dither integrates: two disjoint stretches of the sequence agree',
        dither.shipped.rms < 8,
        `phases 0 and ${ DITHER_PHASE }, ${ DITHER_FRAMES } converged frames apiece, ` +
            `${ dither.shipped.rms.toFixed( 4 ) } cv RMS over the groom with ` +
            `${ dither.shipped.overTwoPercent.toFixed( 2 ) }% of it over 2 cv. ⚠️ THIS CLAUSE IS NOT ` +
            'SUFFICIENT ON ITS OWN and C2 is its liveness control — measured, by deleting ' +
            '`.add( offset )` from hairDitherThresholdNode: C1 then reads 0.0003 cv and goes GREEN, ' +
            'because a seed nothing reads makes both observers agree exactly. LEARNINGS §1.25g.'
    );

    // C2 — THE RED PROOF, and it is the defect the arm was built to remove. With the offset pinned
    // the threshold field never changes, so the resolve reprojects one pattern instead of averaging
    // many and the picture IS the seed. This is `hash`'s failure mode with nothing else moved.
    report(
        'C2 RED PROOF: with the offset frozen the picture is the seed, not the coverage',
        dither[ 'frozen-dither' ].rms > 10 && dither[ 'frozen-dither' ].rms > 3 * dither.shipped.rms,
        `frozen-dither takes the same plate from ${ dither.shipped.rms.toFixed( 4 ) } cv RMS to ` +
            `${ dither[ 'frozen-dither' ].rms.toFixed( 4 ) } — ` +
            `${ ( dither[ 'frozen-dither' ].rms / dither.shipped.rms ).toFixed( 2 ) }x — with ` +
            `${ dither[ 'frozen-dither' ].overTwoPercent.toFixed( 2 ) }% of the groom over 2 cv against ` +
            `${ dither.shipped.overTwoPercent.toFixed( 2 ) }%. Same arm, same frames, same everything ` +
            'but whether the threshold advances.'
    );

    // C3 — and the STEP is load-bearing, not just the movement. White noise advances every frame
    // and still leaves a third more dust after the same number of frames, because an O(1/sqrt N)
    // estimator given 128 samples is an O(1/N) estimator given 11.
    report(
        'C3 the golden step beats white noise at the same frame count, which is why it is not a hash',
        dither[ 'white-dither' ].rms > 1.15 * dither.shipped.rms,
        `white-dither ${ dither[ 'white-dither' ].rms.toFixed( 4 ) } cv against the golden step's ` +
            `${ dither.shipped.rms.toFixed( 4 ) } — ${ ( dither[ 'white-dither' ].rms / dither.shipped.rms ).toFixed( 2 ) }x — ` +
            'after the same 128 frames. Both move every frame; only one is stratified.'
    );

}

await browser?.close();
await server?.close();

// ---------------------------------------------------------------------------------------------
// statistics
// ---------------------------------------------------------------------------------------------

/**
 * A PNG screenshot in the shape `MotionProbe`'s statistics read.
 *
 * `png.mjs` calls the sample array `pixels` and hands back a `Float32Array` normalised to 0..1;
 * `codeValueAt` multiplies by 255. Both facts are stated in `MotionProbe.lumaAt`'s ⚠️, and getting
 * either wrong reads every plate a thousand times too dark while still looking plausible.
 */
function decodePlate( screenshot ) {

    const { width, height, pixels } = decodePng( screenshot );

    return { width, height, data: pixels };

}

/**
 * Difference between two plates over a stated list of pixels, in 8-bit code values.
 *
 * A LIST rather than a rect, because the mask is measured off a pair of plates (every pixel the
 * groom moves) rather than drawn by hand, and rule 4 wants the mask to be the thing it claims to
 * be. `frameDifference` below is whole-frame for the order clauses, where the untouched pixels are
 * identical by construction and dilute nothing.
 */
function maskedDifference( a, b, pixels ) {

    let sumSquares = 0;
    let max = 0;
    let overTwo = 0;

    for ( const [ x, y ] of pixels ) {

        const difference = probe.codeValueAt( a, x, y ) - probe.codeValueAt( b, x, y );
        const magnitude = Math.abs( difference );

        sumSquares += difference * difference;

        if ( magnitude > max ) max = magnitude;
        if ( magnitude > 2 ) overTwo += 1;

    }

    return {
        rms: Math.sqrt( sumSquares / pixels.length ),
        max,
        overTwoPercent: ( 100 * overTwo ) / pixels.length
    };

}

/**
 * Whole-frame difference between two plates, in 8-bit code values.
 *
 * Whole-frame and not a rect: the face, the shoulders and the background are identical between the
 * two draw orders by construction, so they contribute exactly zero and dilute nothing that matters.
 * Choosing a rect would be choosing where to look for the artefact.
 *
 * 🎯 `differing` IS THE STATISTIC A3b IS BUILT ON, and it is a COUNT with no threshold in it. The
 * `overTwo` share above it needs one, and on a depth-resolved arm that share is two or three counts
 * — a quantity no bound can be set against, which is round 19's finding. `differing` reads 237 on
 * the same arm and the same plates, and the same-url floor beside it is exactly 0, so the count is
 * the artefact with nothing else in it.
 */
function frameDifference( a, b ) {

    let sumSquares = 0;
    let count = 0;
    let max = 0;
    let overTwo = 0;
    let differing = 0;

    for ( let y = 0; y < a.height; y ++ ) {

        for ( let x = 0; x < a.width; x ++ ) {

            const difference = probe.codeValueAt( a, x, y ) - probe.codeValueAt( b, x, y );
            const magnitude = Math.abs( difference );

            sumSquares += difference * difference;
            count += 1;

            if ( magnitude > max ) max = magnitude;
            if ( magnitude > 2 ) overTwo += 1;
            if ( magnitude > 0 ) differing += 1;

        }

    }

    return { rms: Math.sqrt( sumSquares / count ), max, differing, overTwoPercent: ( 100 * overTwo ) / count };

}

/**
 * Per-pixel temporal sigma over a clip, plus the frame-to-frame RMS series.
 *
 * Welford, not a sum of squares: the signal is a variance of order a few code values riding on a
 * mean of order a hundred, and a naive accumulator ends by subtracting two nearly equal large
 * numbers — the low bits it cancels away ARE the answer. `tools/critic/heatmap.mjs` makes the same
 * choice for the same reason and says so at length.
 */
function clipStatistics( frames, rect ) {

    let sigmaSum = 0;
    let pixels = 0;

    for ( let y = rect.y; y < rect.y + rect.height; y ++ ) {

        for ( let x = rect.x; x < rect.x + rect.width; x ++ ) {

            let mean = 0;
            let m2 = 0;
            let seen = 0;

            for ( const frame of frames ) {

                seen += 1;

                const value = probe.codeValueAt( frame, x, y );
                const delta = value - mean;

                mean += delta / seen;
                m2 += delta * ( value - mean );

            }

            sigmaSum += Math.sqrt( m2 / seen );
            pixels += 1;

        }

    }

    const series = [];

    for ( let index = 1; index < frames.length; index ++ ) {

        series.push( probe.temporalRms( frames[ index - 1 ], frames[ index ], rect ) );

    }

    series.sort( ( a, b ) => a - b );

    return {
        sigma: sigmaSum / pixels,
        median: series[ Math.floor( series.length / 2 ) ],
        max: series[ series.length - 1 ]
    };

}

console.log( `\n${ failures === 0 ? 'PASS' : 'FAIL' }: ${ checks - failures }/${ checks } checks green\n` );

process.exitCode = failures === 0 ? 0 : 1;
