/**
 * Wardrobe — punch-list 9.3. `dress(ids)` and `undress()` on a live figure, at runtime.
 *
 * THE PROBLEM THIS CLASS EXISTS TO SOLVE
 * --------------------------------------
 * A garment does not sit on top of the body. It REPLACES a region of it. MakeHuman's mhclo
 * carries a `delete_verts` list for exactly that reason, and it is load-bearing rather than an
 * optimisation: with body hiding stripped, **525 body vertices sit within 2 mm outside the suit
 * shell, 152 of them within 0.5 mm** — z-fighting across the whole torso. With hiding on that
 * collapses to **9 vertices within 2 mm**, all at the garment's own boundary
 * (`docs/research/wardrobe-system.md` §1.2).
 *
 * The pipeline's own answer is a Blender MASK modifier baked at export, and it is fatal here:
 * **a body whose torso has been deleted cannot undress.** So `build_figure.py --hide-mask-attribute`
 * ships the same vertex set as a per-vertex `_HIDE_<ID>` attribute on the whole body, and this
 * class rebuilds the body's index buffer from the union of whichever masks are currently worn.
 *
 * That is not an approximation of the bake. Measured, this repo, g050:
 *
 *     union of _hide_female_casualsuit01 + _hide_shoes01  ->  17,012 triangles
 *     baked build, same two garments                      ->  17,012 triangles
 *     _hide_female_casualsuit01 alone                     ->  21,380 triangles
 *     baked build, suit alone                             ->  21,380 triangles
 *     no mask at all (undressed)                          ->  26,756 triangles
 *
 * `wardrobe.selftest.mjs` re-measures those and — because a count is a weak identity — also
 * compares the kept triangles as a SET of centroids against the baked build, so a mask that
 * flagged the wrong vertices in the right quantity cannot pass.
 *
 * ⚠️ **That sentence stood alone for a round and it was not enough, because a centroid is a MEAN
 * and a mean is invariant under the permutation that matters.** Reversing the winding of every
 * triangle this class rebuilds left the count identical, the centroid multiset identical, and every
 * one of the gate's assertions green — on a body that does not render, since `Human.body` is
 * `doubleSided: false` and a back-facing triangle is culled. The gate now also compares the kept
 * triangles as ORIENTED CORNER TRIPLES (position + UV, canonicalised over rotations only), and
 * asserts intrinsically that every kept triangle's geometric normal agrees with its shading
 * normal — in BOTH regimes, because the restore branch below has no baked artefact to be compared
 * against and a defect there is visible to nothing else.
 *
 * ## Why fragments, and why atomically
 *
 * Garments arrive as their own small GLBs, fetched on demand. Research §3.5 chose that over one
 * atlas GLB because **textures are 81% of a one-garment figure and 87% of a three-garment one**,
 * and VRAM is the wardrobe's binding constraint; a fragment holds only what is worn. Geometry is
 * free either way — a fully dressed figure has FEWER triangles than a nude one, 35,784 against
 * 36,924, because `delete_verts` removes more body than the garment adds.
 *
 * **Every fragment an outfit needs is loaded BEFORE anything on screen changes.** `dress()` awaits
 * all its fetches, then applies the whole outfit in one synchronous block: index rebuild, removals
 * and additions together. No frame can observe a half-applied outfit, which is what makes 9.8's
 * decency invariant enforceable at intermediate states and not just at the endpoints.
 *
 * ## Rebinding, and why the joint order is remapped rather than assumed
 *
 * A fragment GLB carries a copy of the rig, because a skinned glTF mesh has to name its joints.
 * That copy is thrown away: the garment is bound to the FIGURE's live skeleton so it deforms with
 * everything else. The joint arrays are remapped **by bone name**, not by position. Measured on
 * this build the remap is the identity — both GLBs export MPFB's 53-bone `game_engine` rig in the
 * same order — but assuming that is how a rig change becomes a garment that hangs off the wrong
 * limb with no error anywhere. `stats().jointRemapIsIdentity` reports which case you are in.
 *
 * ## 🎯 Where 9.8's decency invariant plugs in — it is one function, and it is already called
 *
 * Pass `decencyFloor`, a function returning the garment ids that must be worn in every reachable
 * state. **`#resolveOutfit` unions it into every outfit, and `dress()`, `undress()`, `putOn()` and
 * `takeOff()` all go through `#resolveOutfit`** — there is no path to the body that skips it.
 * `undress()` is therefore "return to the floor", not "remove everything", and its behaviour with
 * a floor of `[]` is the degenerate case rather than the design. `FoundationLayer` (9.8) is what
 * supplies the floor in practice; nothing in this class knows its name.
 *
 * ## 🎯 `_UNDER_*`: how a garment that can never be removed is still not drawn through a coat
 *
 * 9.8's foundation garments are conformal shells 3 mm off the skin, and the skin they are cut from
 * pokes through `female_casualsuit01` at rest — 26.37% of the covered vertices, worst depth
 * 9.19 mm (punch-list 9.4). On the BODY that does not matter, because the suit's `_HIDE_*` mask
 * deletes the skin underneath. A bra worn under the same suit has no such mask and would poke
 * through it everywhere the skin would.
 *
 * So a garment fragment may carry `_UNDER_<other garment>` attributes, written by
 * `build_figure.py` as a rename of the body's own `_hide_<other garment>` — the same vertices,
 * because a shell cut from the body inherits the body's mapping exactly. This class rebuilds a
 * garment's index buffer from the union of the `_UNDER_*` masks of whatever OPAQUE garments are
 * worn OUTSIDE it, by the same code that rebuilds the body's.
 *
 * ⚠️ **This is not removal and it does not weaken 9.8.** The garment is still worn, still in
 * `worn`, still in every stat; the part of it that is not drawn is the part an opaque garment is
 * covering, which is exactly the condition under which the decency invariant is satisfied by that
 * garment instead. `occlusionOf()` reports it per garment so a gate can assert the pairing rather
 * than trust it, and a MASK or BLEND garment is refused the privilege — you can see through those.
 *
 * ## 🎯 Why adopting a fragment also SHADES it — punch-list 3.9's wardrobe half
 *
 * Three blind judges, given our render beside a reference and told nothing about the project, each
 * put "nothing worn casts a shadow onto the body" in their top three and each named the same
 * instance unprompted: the fedora sits directly over a fully lit forehead. It was a bug, not a
 * missing feature — this class parented every fragment and left `castShadow` and `receiveShadow`
 * at three's default of false, and the only code that set them (`applyShading()` in the testbed)
 * traverses `figure.root` BEFORE the first `dress()` and never runs again.
 *
 * So `#adoptFragment` calls `applyFragmentShading`, and the flags travel with the fragment rather
 * than with whoever remembered to traverse. `shadingOf()` reports the configuration and
 * `shadow.selftest.mjs` measures the consequence in rendered luma, because the flag is not the point —
 * the darkening under the brim is.
 *
 * ⚠️ **AND THE FLAGS WERE ONLY TWO THIRDS OF IT.** With both set, the ONLY contact that darkened
 * was the forehead — a re-judge pair set measured a skirt hem casting onto the thigh below it as
 * BIT-IDENTICAL with shadows on and off. The missing third is `material.shadowSide`, which decides
 * which faces reach the shadow map at all; three's default writes a FrontSide garment's BACK faces,
 * i.e. the far wall of the tube. `applyFragmentShading` now sets it, and `GARMENT_SHADOW_SIDE`
 * carries the measurements. The lesson the file keeps re-learning: a configuration that reads
 * correct is not a rendered consequence.
 */

import { DoubleSide } from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { createGarmentInterior } from './GarmentInterior.js';

/**
 * How a hide-mask attribute name in the manifest is matched against one in the GLB.
 *
 * 🚩 Blender's glTF exporter UPPER-CASES custom attribute names. Authored `_hide_shoes01`, the
 * file carries `_HIDE_SHOES01`, and three.js keeps the exported spelling. Verified on the built
 * file. Every lookup here lowercases both sides.
 */
function normaliseAttributeName( name ) {

    return name.toLowerCase();

}

/** The prefix a garment carries the region it sits underneath another garment in. See the header. */
const UNDER_MASK_PREFIX = '_under_';

/** The prefix the BODY carries a garment's deleted region under. */
const HIDE_MASK_PREFIX = '_hide_';

/**
 * Anisotropic filtering on every garment map, matched to `material/SkinMaterial.js`'s micro-normal.
 *
 * A garment's diffuse arrives through `GLTFLoader` at three's default of 1. On a torso seen at
 * body framing the striped shirt is a texture viewed at a grazing angle over most of its area,
 * which is the exact case isotropic mip selection gets wrong: it picks the mip for the LONG axis
 * and the stripes alias into moire with red and blue fringing. 8 is what the skin already asks for
 * and every desktop GPU supports 16, so this is not a capability question at the sampler.
 */
const GARMENT_TEXTURE_ANISOTROPY = 8;

/**
 * Which face of a worn garment is rendered into the shadow map — and it is NOT three's default.
 *
 * 🚩 **WITHOUT THIS LINE ONLY A HAT CASTS ANYTHING, AND THAT IS NOT A FIGURE OF SPEECH.** three
 * leaves `material.shadowSide` at null, and both shadow paths then render the OPPOSITE of
 * `material.side` into the map (`Renderer.js`: `_shadowSide[ FrontSide ] = BackSide`;
 * `WebGLShadowMap.js` has the same table). Every garment fragment in `assets/wardrobe` is authored
 * `doubleSided: false` — read off all 24 fragment GLBs, not assumed — so every one is FrontSide,
 * so every one of them casts from its BACK faces only.
 *
 * For a hat brim the back face is the brim's underside, about two millimetres above the forehead,
 * which is why the forehead was the ONE contact that worked and the one three blind judges named.
 * For a TUBE — a sleeve, a cuff, a skirt — the back faces are the far wall, decimetres of depth
 * behind the limb inside it, so the limb is never behind an occluder and nothing lands on it at all.
 *
 * Measured this session on `wardrobe.html`, close framing, shadows on against `garment-cast`
 * cleared, changing nothing but this value:
 *
 *     view          shipped (null)                FrontSide          DoubleSide
 *     hem-thigh     0.000% changed, peak 0.00000  1.335% / 0.33627   1.335% / 0.33627
 *     cuff-wrist    0.332% / 0.30253              0.469% / 0.36107   0.469% / 0.36107
 *     hat-forehead  5.941% / 0.46867              5.958% / 0.46867   5.958% / 0.46867
 *
 * The shipped plates are **bit-identical to BackSide** at every one of those views, which is the
 * mechanism above stated as a sha256 rather than as a claim.
 *
 * ## Why DoubleSide and not FrontSide, which reads the same on the table
 *
 * DoubleSide is a strict superset: the depth test keeps the nearest surface either way, so the two
 * agree wherever a light-facing face exists, and where one does NOT — an open shell whose only
 * surface at that pixel points away from the light — FrontSide writes nothing and DoubleSide writes
 * the far face. Measured: the two are byte-identical at four of five views and differ at the cuff,
 * 55 pixels with a peak Δluma of 0.09636, every one of them darker under DoubleSide — all of it
 * DoubleSide finding shadow FrontSide missed.
 *
 * It also cannot regress a garment authored `doubleSided: true`, because DoubleSide is exactly what
 * three's own default gives such a material, while FrontSide would take shadow away from one. No
 * garment in the catalogue is double-sided today, so that is a guard against the future rather than
 * a fix for the present — but it costs nothing to hold.
 *
 * ## What it does NOT cost, measured rather than argued
 *
 * ACNE. Putting the depth on the lit surface is the classic self-shadow-acne configuration, and
 * three's default exists to avoid it on solid closed meshes. A frame filled edge to edge with
 * jacket cloth reads **0.000% of pixels changed** between the shipped value and this one, peak
 * Δluma 0.02491, and its high-frequency energy (mean |Laplacian| of luma) moves from 0.004290 to
 * 0.004290. There is no acne here because a garment is a THIN SHELL over a body that is itself an
 * occluder — the body is left at three's default, which is right for a solid.
 *
 * PETER-PANNING. Under the skirt hem the shadow starts on the FIRST lit pixel below the cloth:
 * mean darkening 0.18434 at +0 px, decaying smoothly to 0.08092 at +39 px, over 802 columns. No
 * detached shadow, no lit gap.
 *
 * DRAW COST. 200 serialized renders, the same outfit, counted off `renderer.info`: **2,885 draw
 * calls and 8,874,893 triangles, identical to the unit** at null, FrontSide and DoubleSide. The
 * shadow pass submits the same geometry; only the rasterizer's cull state differs. Frame time is
 * unmoved (median 8.300 ms in all three, p95 9.2–9.3 ms).
 *
 * ⚠️ **DO NOT "CLEAN THIS UP" AS A MYSTERIOUS ASSIGNMENT.** Delete it and `hem-thigh` goes back to
 * bit-identical — a skirt hem, a cuff and a sleeve cast NOTHING onto the limb inside them, the
 * flags still read true, and `shadingOf()` still says the fragment is configured. That is the
 * shape of the defect this whole file already got caught by once.
 */
const GARMENT_SHADOW_SIDE = DoubleSide;

/**
 * 🎯 Wardrobe's half of punch-list 3.9, and it is why nothing worn cast a shadow for a whole phase.
 *
 * three defaults `castShadow` and `receiveShadow` to FALSE on every Object3D. The testbed's
 * `applyShading()` traverses `figure.root` and sets both — and it runs BEFORE `dress()`, so every
 * fragment parented afterwards arrives with both flags false and there is no second traverse. The
 * result reads exactly as three blind judges described it: a fedora over a fully lit forehead.
 *
 * ⚠️ **BOTH FLAGS, and the second one is the one that gets dropped.** `castShadow` alone gives the
 * hat a shadow on the FACE and leaves the jacket beneath it lit as if the hat were not there — a
 * garment has to receive what the body and the garments outside it cast, not only cast its own.
 * The source assets agree: every CC0 mhmat in the catalogue declares `castShadows True` and
 * `receiveShadows True`, and the game-engine material path threw both away with the AO map.
 *
 * Applied per fragment at adopt time rather than by a traverse the caller has to remember, because
 * "the caller remembers" is the mechanism that failed.
 */
function applyFragmentShading( mesh ) {

    mesh.castShadow = true;
    mesh.receiveShadow = true;

    for ( const material of materialsOf( mesh ) ) {

        // 🚩 THE FLAGS ABOVE ARE NOT ENOUGH ON THEIR OWN, AND ROUND 11 SHIPPED BELIEVING THEY WERE.
        // `castShadow` says the mesh is submitted to the shadow map; this says WHICH OF ITS FACES
        // gets written there, and three's default writes the wrong one for a thin shell. With this
        // line removed a skirt hem, a cuff and a sleeve cast nothing at all onto the limb inside
        // them — the plates come back bit-identical — while every flag still reads true. See
        // `GARMENT_SHADOW_SIDE` for the measurements and for why it is DoubleSide.
        material.shadowSide = GARMENT_SHADOW_SIDE;

        for ( const value of Object.values( material ) ) {

            if ( value === null || value?.isTexture !== true ) continue;

            value.anisotropy = GARMENT_TEXTURE_ANISOTROPY;
            value.needsUpdate = true;

        }

        // glTF's occlusion texture lands on `aoMap`, and three has historically sampled `aoMap`
        // from UV channel 1. A garment exported from MPFB has exactly one UV set, so pointing
        // channel 1 at it is what the asset means when its occlusion texture says `"texCoord": 0`.
        //
        // ⚠️ MEASURED AS DEFENSIVE, NOT LOAD-BEARING, on three r185's WebGPU path. With this line
        // removed the jacket renders byte-identically — 0.26781 with the AO map and 0.27026
        // without, the same two numbers to five decimals — so the node graph already falls back to
        // `uv`. It is kept because the fallback is an implementation detail of one renderer and
        // one version, and because a garment that ever does carry a second UV set would otherwise
        // sample the AO map through the wrong one. `wardrobe.selftest.mjs` gates the pairing.
        if ( material.aoMap != null && mesh.geometry.attributes.uv1 === undefined &&
            mesh.geometry.attributes.uv !== undefined ) {

            mesh.geometry.setAttribute( 'uv1', mesh.geometry.attributes.uv );

        }

    }

}

/** A mesh's materials as an array, so a multi-material fragment is not silently half-treated. */
function materialsOf( mesh ) {

    return Array.isArray( mesh.material ) ? mesh.material : [ mesh.material ];

}

/** Every `_hide_*` / `_under_*` attribute on a geometry, keyed by its lowercased name. */
function maskAttributesOf( geometry, prefix ) {

    const found = new Map();

    for ( const [ name, attribute ] of Object.entries( geometry.attributes ) ) {

        if ( normaliseAttributeName( name ).startsWith( prefix ) === false ) continue;

        found.set( normaliseAttributeName( name ), attribute );

    }

    return found;

}

/**
 * A per-vertex 0/1 array over the union of the named masks, or null when nothing is hidden.
 *
 * Exported as a free function because the body and every garment run the same union: the body's
 * masks are named `_hide_<id>` and a garment's are named `_under_<id>`, and past the naming there
 * is one rule.
 */
function unionOfMasks( attributes, names, vertexCount ) {

    const present = names
        .map( ( name ) => attributes.get( normaliseAttributeName( name ) ) )
        .filter( ( attribute ) => attribute !== undefined );

    if ( present.length === 0 ) return null;

    const hidden = new Uint8Array( vertexCount );

    for ( const attribute of present ) {

        for ( let vertex = 0; vertex < vertexCount; vertex += 1 ) {

            // Exported as FLOAT. Anything above a half is flagged; the writer only ever sets
            // 0.0 or 1.0, and a threshold beats an equality test on a float that has been
            // through a file.
            if ( attribute.getX( vertex ) > 0.5 ) hidden[ vertex ] = 1;

        }

    }

    return hidden;

}

/**
 * Rewrites a geometry's index buffer to the triangles none of whose vertices is hidden.
 *
 * 🚩 **THE ORDER `a, b, c` IS LOAD-BEARING IN BOTH BRANCHES.** The body is backface culled, so a
 * triangle written the other way round is not drawn — and reordering an index buffer is exactly
 * the shape a plausible cache-locality "optimisation" takes. Two of them were tried against this
 * function: a full reversal, and a canonicalisation putting the lowest index first, which reverses
 * 6,897 of 21,380 triangles. Both leave the count and the centroid multiset untouched.
 * `wardrobe.selftest.mjs` catches both; nothing else in the repo does.
 *
 * "Any vertex hidden drops the triangle" is not a choice either — it is what Blender's MASK
 * modifier does, and reproducing the bake exactly is the whole claim.
 *
 * The index array is edited in place and the tail is cut off with `drawRange` rather than
 * reallocated: same GPU buffer, one upload, and the full triangle list is still there to restore
 * from when the garment comes off.
 */
function rebuildIndex( geometry, fullIndex, hidden ) {

    const index = geometry.index;

    if ( hidden === null ) {

        index.array.set( fullIndex );
        index.needsUpdate = true;
        geometry.setDrawRange( 0, fullIndex.length );
        return fullIndex.length;

    }

    const target = index.array;
    let written = 0;

    for ( let offset = 0; offset < fullIndex.length; offset += 3 ) {

        const a = fullIndex[ offset ];
        const b = fullIndex[ offset + 1 ];
        const c = fullIndex[ offset + 2 ];

        if ( hidden[ a ] === 1 || hidden[ b ] === 1 || hidden[ c ] === 1 ) continue;

        target[ written ] = a;
        target[ written + 1 ] = b;
        target[ written + 2 ] = c;
        written += 3;

    }

    index.needsUpdate = true;
    geometry.setDrawRange( 0, written );

    return written;

}

export class Wardrobe {

    /**
     * @param {Figure} figure - A loaded figure. `figure.body` must be the skinned body mesh and
     *   must carry the `_HIDE_*` attributes — i.e. built with `--hide-mask-attribute`.
     * @param {GarmentManifest} manifest
     * @param {Object} [options]
     * @param {string} [options.figureKey='g050'] - Which per-figure fragment to fetch. A garment
     *   fragment CANNOT be shared across the five figures: `female_casualsuit01` drifts mean
     *   95.145 mm / max 143.066 mm between g000 and g100, and cross-fitting puts 84.4% of the
     *   covered skin outside the cloth (research §3.3).
     * @param {() => string[]} [options.decencyFloor] - Punch-list 9.8's hook. See the header.
     * @param {(url: string) => Promise<Object>} [options.loadFragment] - Fetches and parses one
     *   fragment GLB, given the URL the manifest resolves to. Injected so the node selftest can
     *   read from disk.
     */
    constructor( figure, manifest, options = {} ) {

        this.disposed = false;
        this.dressToken = 0;
        this.loadingOutfit = null;
        this.pendingFragments = new Map();

        this.figure = figure;
        this.manifest = manifest;

        this.figureKey = options.figureKey ?? 'g050';
        this.decencyFloor = options.decencyFloor ?? ( () => [] );
        this.loadFragment = options.loadFragment ?? defaultFragmentLoader;
        // Fixed for this wardrobe lifetime: cached fragments are keyed by garment ID.
        Object.defineProperty( this, 'materialStyle', { value: options.materialStyle ?? 'original', enumerable: true } );
        this.createMaterial = options.createMaterial ?? null;

        this.body = figure.body;

        if ( this.body === null || this.body === undefined ) {

            throw new Error( 'Wardrobe: the figure has no body mesh to dress.' );

        }

        // The undressed index buffer, kept whole. Every rebuild starts from this, so dressing and
        // undressing cannot accumulate drift — the body is never edited, only re-indexed.
        const index = this.body.geometry.index;

        if ( index === null ) {

            throw new Error( 'Wardrobe: the body geometry is not indexed, so there is no index ' +
                'buffer to rebuild.' );

        }

        this.fullIndex = index.array.slice();
        this.fullTriangleCount = this.fullIndex.length / 3;

        // 🚩 A geometry with material groups ignores drawRange entirely — three renders the groups
        // instead. The body has exactly one material, so a group here means the pipeline changed
        // under us and the hide rebuild would silently do nothing.
        if ( this.body.geometry.groups.length > 1 ) {

            throw new Error( `Wardrobe: the body geometry has ${ this.body.geometry.groups.length } ` +
                'material groups; drawRange would be ignored and hiding would silently fail.' );

        }

        this.hideAttributes = maskAttributesOf( this.body.geometry, HIDE_MASK_PREFIX );
        this.#warnIfNoHideMasks();
        this.fragments = new Map();      // garment id -> { mesh, jointRemapIsIdentity }
        this.wornMeshes = new Map();     // garment id -> SkinnedMesh currently in the scene
        this.worn = [];                  // garment ids, innermost first

        this.lastDressMs = 0;
        this.lastRebuildMs = 0;

        // A fresh geometry's drawRange is (0, Infinity). Normalising it here means `stats()`
        // reports a real triangle count before the first `dress()` rather than Infinity.
        this.#rebuildBodyIndex( [] );

        // 🚩 THE FRAME BETWEEN CONSTRUCTION AND THE FIRST `dress()`, which is a real frame.
        //
        // A wardrobe is built over a figure that is already in the scene, and the first outfit has
        // to fetch its fragments over the network before anything can be worn. Every frame drawn
        // in that window is a bare body — measured by `decency.selftest.mjs`, which samples the
        // live scene at every point the event loop can yield during a change and found six
        // indecent samples, all of them in the first dress.
        //
        // So a figure with a decency floor does not DRAW until the floor is on. Not "is dressed
        // in a placeholder", not "fades in" — not drawn, which is the only state that is
        // guaranteed decent. A wardrobe with no floor is unchanged: `alive.html?wear=…` passes no
        // `decencyFloor`, so `hasFloor` is false and the body is visible exactly as before.
        this.dressedAtLeastOnce = false;
        this.body.visible = this.#hasFloor() === false;

    }

    /**
     * Loads a manifest and returns a Wardrobe over the given figure.
     *
     * @param {Figure} figure
     * @param {string} manifestUrl
     * @param {Object} [options] - As the constructor.
     */
    static async create( figure, manifestUrl, options = {} ) {

        const { GarmentManifest } = await import( './GarmentManifest.js' );
        return new Wardrobe( figure, await GarmentManifest.load( manifestUrl ), options );

    }

    /**
     * Wears exactly this outfit, plus whatever the decency floor requires. Absolute, not additive.
     *
     * Rejects an outfit whose garments would interpenetrate before it touches anything, because
     * MPFB will not: two suits at the same layer both attach, both delete groups apply as a union,
     * and there is no warning (research §2.2).
     *
     * @param {string[]} garmentIds
     * @returns {Promise<Object>} the same shape as `stats()`
     */
    async dress( garmentIds ) {

        const outfit = this.validateOutfit( garmentIds );
        const token = ++ this.dressToken;
        this.loadingOutfit = outfit;
        try {

            // A newer valid request wins even if an older load finishes last. Nothing changes on
            // screen until every required fragment has arrived; failures preserve the old outfit.
            for ( const id of outfit ) {

                await this.#fragmentFor( id );
                this.#requireLive();
                if ( token !== this.dressToken ) return this.stats();

            }
            const startedAt = now();
            this.#applyOutfit( outfit );
            this.lastDressMs = now() - startedAt;
            return this.stats();

        } finally {

            if ( token === this.dressToken ) this.loadingOutfit = null;

        }

    }

    /** Validate through the same policy as dress(), without starting a load or changing an outfit. */
    validateOutfit( garmentIds ) {

        this.#requireLive();
        if ( !Array.isArray( garmentIds ) || garmentIds.some( id => typeof id !== 'string' || id.length === 0 ) ) {

            throw new TypeError( 'Wardrobe: outfit must be an array of nonempty garment ids.' );

        }
        const outfit = this.#resolveOutfit( garmentIds );
        const conflicts = this.manifest.conflicts( outfit );
        if ( conflicts.length > 0 ) throw new Error( `Wardrobe: this outfit cannot be worn:\n  ${ conflicts.join( '\n  ' ) }` );
        for ( const id of outfit ) this.manifest.fragmentUrl( id, this.figureKey );
        return outfit;

    }

    /**
     * Returns to the decency floor — today that is nothing, and when 9.8 lands it is the
     * foundation layer. Deliberately NOT "remove every garment": see the header.
     */
    async undress() {

        return this.dress( [] );

    }

    /** Adds garments to what is already worn. */
    async putOn( garmentIds ) {

        return this.dress( [ ...this.worn, ...garmentIds ] );

    }

    /** Removes garments from what is worn. The floor is re-added by `#resolveOutfit`. */
    async takeOff( garmentIds ) {

        const removing = new Set( garmentIds );
        return this.dress( this.worn.filter( ( id ) => removing.has( id ) === false ) );

    }

    /** Observe the applied material identities; a requested style alone is not an attachment. */
    appearance() {
        return {
            style: this.materialStyle,
            attached: !this.disposed && this.worn.every( id => {
                const fragment = this.fragments.get( id );
                return !!fragment && fragment.mesh.material === fragment.appliedMaterial;
            } )
        };
    }

    /** What is worn, what it costs, and what the body currently draws. */
    stats() {

        return {
            disposed: this.disposed,
            pendingFragments: this.pendingFragments.size,
            worn: [ ...this.worn ],
            bodyVisible: this.body.visible,
            bodyTriangles: this.body.geometry.drawRange.count / 3,
            fullBodyTriangles: this.fullTriangleCount,
            hiddenTriangles: this.fullTriangleCount - this.body.geometry.drawRange.count / 3,
            garmentTriangles: this.worn.reduce(
                ( total, id ) => {
                    const fragment = this.fragments.get( id );
                    return total + fragment.drawnTriangles + ( fragment.interior?.drawnTriangles ?? 0 );
                }, 0 ),
            occlusion: this.occlusionOf(),
            drawCalls: 1 + this.wornMeshes.size + this.worn.reduce(
                ( total, id ) => total + ( this.fragments.get( id ).interior?.drawCalls ?? 0 ), 0 ),
            residentFragments: this.fragments.size,
            insulation: this.manifest.insulationOf( this.worn ),
            lastDressMs: this.lastDressMs,
            lastRebuildMs: this.lastRebuildMs,
            jointRemapIsIdentity: [ ...this.fragments.values() ]
                .every( ( fragment ) => fragment.jointRemapIsIdentity )
        };

    }

    /**
     * Per worn garment: how much of it is drawn, and which OPAQUE outer garments cover the rest.
     *
     * 🎯 This is what makes `_UNDER_*` auditable rather than a claim. 9.8's invariant is that the
     * foundation layer is worn in every reachable state; the interesting question is whether the
     * part of it that is NOT drawn is exactly the part something opaque is covering, and a gate
     * can only ask that if the runtime says which garment did the covering.
     */
    occlusionOf() {

        return this.worn.map( ( id ) => {

            const fragment = this.fragments.get( id );

            return {
                id,
                drawnTriangles: fragment.drawnTriangles,
                fullTriangles: fragment.fullTriangles,
                occludedBy: [ ...fragment.occludedBy ],
                carriesUnderMasks: fragment.underMasks.size > 0
            };

        } );

    }

    /**
     * Per worn garment: the shadow flags, the sampler anisotropy, and whether an AO map arrived.
     *
     * 🚩 This is the WEAK half of the gate on `applyFragmentShading` and it is labelled one. A flag
     * being true says the fragment was configured; it does not say a shadow landed on anything, and
     * the defect this reports on was invisible for a phase precisely because everybody looked at
     * configuration. `shadow.selftest.mjs` measures the rendered luma; this exists so that when the
     * rendered gate goes red a reader can tell a cleared flag from a moved light in one line.
     */
    shadingOf() {

        return this.worn.map( ( id ) => {

            const mesh = this.fragments.get( id ).mesh;
            const materials = materialsOf( mesh );
            const textures = materials.flatMap( ( material ) => Object.values( material )
                .filter( ( value ) => value !== null && value?.isTexture === true ) );

            return {
                id,
                castShadow: mesh.castShadow,
                receiveShadow: mesh.receiveShadow,
                // Reported beside the flags because it is the third member of the same fix and the
                // one with no visible symptom of its own: a fragment can read cast/receive true and
                // still put its far wall in the shadow map. `null` here means three's default is in
                // force, which for these FrontSide garments means BACK faces only.
                shadowSide: materials.map( ( material ) => material.shadowSide ),
                side: materials.map( ( material ) => material.side ),
                textures: textures.length,
                minAnisotropy: textures.length === 0 ? null
                    : Math.min( ...textures.map( ( texture ) => texture.anisotropy ) ),
                hasAoMap: materials.some( ( material ) => material.aoMap != null ),
                hasUv1: mesh.geometry.attributes.uv1 !== undefined
            };

        } );

    }

    /** Hide-mask attribute names the body actually carries, in the file's own spelling. */
    availableHideMasks() {

        return [ ...this.hideAttributes.keys() ];

    }

    /**
     * Frees a garment's GPU memory and forgets it, so putting it back on refetches.
     *
     * A garment taken off stays cached by default, because the second wearing is then free and an
     * avatar changing outfits by mood will wear the same few things repeatedly. That is a
     * deliberate trade AGAINST research §3.4, which names VRAM as the wardrobe's binding
     * constraint — one 4096² RGBA8 normal is ≈85 MB resident with mips, and the measured fragment
     * for `female_casualsuit01` carries 8.76 MB of PNG for two maps. So the trade needs an escape
     * hatch, and this is it: call `release` on what the avatar is done with.
     *
     * A worn garment is refused rather than pulled off the figure underneath the caller.
     */
    release( id ) {

        this.#requireLive();
        if ( this.pendingFragments.has( id ) || this.loadingOutfit?.includes( id ) ) {

            throw new Error( `Wardrobe: '${ id }' is required by an outfit still loading.` );

        }

        if ( this.wornMeshes.has( id ) ) {

            throw new Error( `Wardrobe: '${ id }' is being worn. Take it off before releasing it.` );

        }

        const fragment = this.fragments.get( id );
        if ( fragment === undefined ) return false;

        fragment.interior?.dispose();
        disposeGarmentResources( fragment.resources );
        this.fragments.delete( id );

        return true;

    }

    /**
     * Retire this wardrobe's fragments, including cached unworn garments. The body and its shared
     * skeleton belong to the caller. Pending loads dispose their resources when they arrive and
     * cannot reattach. With a foundation floor, hide the borrowed body before removing its cover.
     */
    dispose() {

        if ( this.disposed ) return;
        this.disposed = true;
        ++ this.dressToken;
        this.loadingOutfit = null;
        if ( this.#hasFloor() ) this.body.visible = false;
        for ( const mesh of this.wornMeshes.values() ) mesh.removeFromParent();
        this.wornMeshes.clear();
        this.worn = [];
        for ( const fragment of this.fragments.values() ) {
            fragment.interior?.dispose();
            disposeGarmentResources( fragment.resources );
        }
        this.fragments.clear();
        this.#rebuildBodyIndex( [] );

    }

    #requireLive() {

        if ( this.disposed ) throw new Error( 'Wardrobe: this wardrobe has been disposed.' );

    }

    // --- the outfit ------------------------------------------------------------------------

    /**
     * 🎯 The single funnel every outfit passes through, and 9.8's insertion point.
     *
     * De-duplicates, unions in the decency floor, and sorts innermost-first so two runs of the
     * same outfit dress in the same sequence and a diff against the worn set is comparable.
     */
    #resolveOutfit( garmentIds ) {

        const wanted = new Set( [ ...this.decencyFloor(), ...garmentIds ] );

        for ( const id of wanted ) this.manifest.require( id );

        return this.manifest.sortByLayer( [ ...wanted ] );

    }

    /**
     * Puts the outfit on, synchronously and completely. Every fragment is already loaded.
     *
     * Order is deliberate: rebuild the body first, then remove what is leaving, then add what is
     * arriving. All three happen inside one call, between two frames.
     */
    #applyOutfit( outfit ) {

        const startedAt = now();
        this.#rebuildBodyIndex( this.manifest.hideMasksFor( outfit ) );
        this.#rebuildGarmentIndices( outfit );
        this.lastRebuildMs = now() - startedAt;

        const arriving = new Set( outfit );

        for ( const [ id, mesh ] of this.wornMeshes ) {

            if ( arriving.has( id ) ) continue;

            mesh.removeFromParent();
            this.wornMeshes.delete( id );

        }

        for ( const id of outfit ) {

            if ( this.wornMeshes.has( id ) ) continue;

            const mesh = this.fragments.get( id ).mesh;
            this.body.parent.add( mesh );
            this.wornMeshes.set( id, mesh );

        }

        this.worn = outfit;

        // The floor is on. From here the body draws, and never stops.
        this.dressedAtLeastOnce = true;
        this.body.visible = true;

    }

    /** Whether a decency floor is configured. A floor that throws counts as one — see the header. */
    #hasFloor() {

        try {

            return this.decencyFloor().length > 0;

        } catch ( error ) {

            console.warn( `Wardrobe: the decency floor threw (${ error.message }). Treating the ` +
                'figure as one that has a floor, so it stays hidden until it is dressed.' );
            return true;

        }

    }

    /** Rebuilds the body's index buffer from the union of the worn garments' hide masks. */
    #rebuildBodyIndex( hideMaskNames ) {

        const geometry = this.body.geometry;
        const hidden = unionOfMasks( this.hideAttributes, hideMaskNames,
            geometry.attributes.position.count );

        rebuildIndex( geometry, this.fullIndex, hidden );

    }

    /**
     * Rebuilds each worn garment's index buffer from what is worn OPAQUE outside it.
     *
     * A garment with no `_UNDER_*` attributes — every mhclo garment in the catalogue — is restored
     * whole every time, which costs one `set()` on an already-resident buffer and means this
     * method has no special case for "the ordinary garment".
     */
    #rebuildGarmentIndices( outfit ) {

        for ( const id of outfit ) {

            const fragment = this.fragments.get( id );
            const geometry = fragment.mesh.geometry;

            // Only garments this fragment actually carries a mask for. Reporting every opaque
            // outer garment as an occluder would name `shoes01` as covering a bra, which is true
            // of the sort order and false of the geometry.
            const covering = outfit.filter( ( other ) => other !== id &&
                this.manifest.orderOf( other ) > this.manifest.orderOf( id ) &&
                this.manifest.get( other ).alphaMode === 'OPAQUE' &&
                fragment.underMasks.has( `${ UNDER_MASK_PREFIX }${ other }` ) );

            const hidden = unionOfMasks( fragment.underMasks,
                covering.map( ( other ) => `${ UNDER_MASK_PREFIX }${ other }` ),
                geometry.attributes.position.count );

            const drawn = rebuildIndex( geometry, fragment.fullIndex, hidden );
            // Interior faces must follow the same any-corner mask as their outer source triangles.
            fragment.interior?.syncMask( hidden );

            fragment.drawnTriangles = drawn / 3;
            fragment.occludedBy = hidden === null ? [] : covering;

        }

    }

    /**
     * 🚩 An empty hide-mask map is the silent failure this whole path is exposed to: Blender's
     * glTF exporter has `export_attributes` OFF by default, and a build without it succeeds,
     * reports success, and produces a figure that can wear a garment and never hide anything under
     * it. So an empty map is not treated as "no garments in the catalogue" — the caller is told,
     * once, at load.
     */
    #warnIfNoHideMasks() {

        if ( this.hideAttributes.size > 0 ) return;

        console.warn( 'Wardrobe: the body carries no _HIDE_* attributes. Rebuild it with ' +
            '`build_figure.py --hide-mask-attribute` — without them a garment will be worn ' +
            'over a body that is still fully drawn underneath it.' );

    }

    // --- fragments -------------------------------------------------------------------------

    /** Loads one garment fragment, rebinds it to the figure's skeleton, and caches it. */
    async #fragmentFor( id ) {

        this.#requireLive();
        const cached = this.fragments.get( id );
        if ( cached !== undefined ) return cached;
        const pending = this.pendingFragments.get( id );
        if ( pending !== undefined ) return pending;

        const request = ( async () => {

            const gltf = await this.loadFragment( this.manifest.fragmentUrl( id, this.figureKey ), id );
            // Capture ownership BEFORE adoption reparents the mesh and replaces its skeleton.
            // These resources came from this load, never from the body's borrowed skeleton.
            const resources = garmentResourcesOf( gltf.scene );
            try {

                this.#requireLive();
                const fragment = this.#adoptFragment( id, gltf, resources );
                fragment.resources = resources;
                this.fragments.set( id, fragment );
                return fragment;

            } catch ( error ) {

                disposeGarmentResources( resources );
                throw error;

            }

        } )();
        this.pendingFragments.set( id, request );
        try { return await request; }
        finally { if ( this.pendingFragments.get( id ) === request ) this.pendingFragments.delete( id ); }

    }

    /**
     * Takes the skinned mesh out of a fragment GLB and binds it to the figure's own skeleton.
     *
     * The fragment's copy of the rig is discarded. What is kept is the geometry, the material and
     * the skin weights — and the joint indices are rewritten through a name lookup into the
     * figure's skeleton, so a rig whose bone ORDER changed produces a loud error here rather than
     * a garment that follows the wrong limb.
     */
    #adoptFragment( id, gltf, resources ) {

        let garmentMesh = null;
        gltf.scene.traverse( ( object ) => {

            if ( object.isSkinnedMesh === true && garmentMesh === null ) garmentMesh = object;

        } );

        if ( garmentMesh === null ) {

            throw new Error( `Wardrobe: the fragment for '${ id }' contains no SkinnedMesh.` );

        }

        // Synchronous factory contract: null keeps the original; a returned Material transfers
        // ownership here. A factory must retire its own allocations if it throws before return.
        // Register before installing/adopting so later validation failures retire both materials.
        const replacement = this.createMaterial?.( id, garmentMesh );
        if ( replacement != null ) {
            if ( !replacement.isMaterial ) throw new TypeError( 'Wardrobe: material factory must return a Material or null.' );
            resources.materials.add( replacement );
            garmentMesh.material = replacement;
        }

        const remap = this.#jointRemapFor( id, garmentMesh.skeleton );
        const identity = remap.every( ( target, source ) => target === source );

        if ( identity === false ) rewriteJointIndices( garmentMesh.geometry, remap );

        garmentMesh.name = `garment_${ id }`;
        garmentMesh.removeFromParent();

        // The skinning shader still multiplies by the mesh's own world matrix, so a garment that
        // is not posed like the body it was fitted to would be skinned correctly and drawn in the
        // wrong place. Both come off the same rig at identity, and this keeps them that way.
        garmentMesh.position.copy( this.body.position );
        garmentMesh.quaternion.copy( this.body.quaternion );
        garmentMesh.scale.copy( this.body.scale );

        garmentMesh.bind( this.figure.skeleton ?? this.body.skeleton, this.body.bindMatrix );

        // A garment is skinned to the same bones as the body, so it is inside the same shadow and
        // frustum volume; three's per-object cull would otherwise use the fragment's own bind-pose
        // bounds, which do not follow the pose.
        garmentMesh.frustumCulled = false;

        // 🎯 Shadows, filtering and the AO channel. See `applyFragmentShading` — this call is the
        // whole of punch-list 3.9's wardrobe half, and it is here rather than in the page because
        // a page that forgets it produces a hat that floats over a lit forehead with no error.
        applyFragmentShading( garmentMesh );

        const fragment = {
            mesh: garmentMesh,
            appliedMaterial: garmentMesh.material,
            jointRemapIsIdentity: identity,
            underMasks: maskAttributesOf( garmentMesh.geometry, UNDER_MASK_PREFIX ),
            fullIndex: garmentMesh.geometry.index.array.slice(),
            fullTriangles: garmentMesh.geometry.index.count / 3,
            drawnTriangles: garmentMesh.geometry.index.count / 3,
            occludedBy: []
        };
        // Install only after joint adoption, material selection and shading; the helper owns
        // cloned geometry/material and borrows this body's skeleton and imported textures.
        fragment.interior = createGarmentInterior( garmentMesh, { fullIndex: fragment.fullIndex, resources } );
        return fragment;

    }

    /** For each joint slot in the fragment's skeleton, which slot the figure's skeleton uses. */
    #jointRemapFor( id, fragmentSkeleton ) {

        const figureSkeleton = this.figure.skeleton ?? this.body.skeleton;
        const byName = new Map( figureSkeleton.bones.map( ( bone, slot ) => [ bone.name, slot ] ) );

        return fragmentSkeleton.bones.map( ( bone ) => {

            const slot = byName.get( bone.name );

            if ( slot === undefined ) {

                throw new Error( `Wardrobe: '${ id }' is skinned to a bone named '${ bone.name }' ` +
                    'that the figure\'s skeleton does not have.' );

            }

            return slot;

        } );

    }

}

/** Rewrites a skinned geometry's joint indices through a slot remap, in place. */
function rewriteJointIndices( geometry, remap ) {

    const skinIndex = geometry.attributes.skinIndex;

    for ( let vertex = 0; vertex < skinIndex.count; vertex += 1 ) {

        skinIndex.setXYZW(
            vertex,
            remap[ skinIndex.getX( vertex ) ],
            remap[ skinIndex.getY( vertex ) ],
            remap[ skinIndex.getZ( vertex ) ],
            remap[ skinIndex.getW( vertex ) ] );

    }

    skinIndex.needsUpdate = true;

}

async function defaultFragmentLoader( url ) {

    return new GLTFLoader().loadAsync( url );

}

function now() {

    return typeof performance !== 'undefined' ? performance.now() : Date.now();

}

/** The GLB load transfers these resources to the wardrobe, including any unused fragment meshes. */
function garmentResourcesOf( root ) {

    const resources = { geometries: new Set(), materials: new Set(), textures: new Set(), skeletons: new Set() };
    root.traverse( object => {

        if ( !object.isMesh ) return;
        resources.geometries.add( object.geometry );
        if ( object.skeleton ) resources.skeletons.add( object.skeleton );
        for ( const material of materialsOf( object ) ) {

            if ( !material ) continue;
            resources.materials.add( material );
            for ( const value of Object.values( material ) ) if ( value?.isTexture ) resources.textures.add( value );

        }

    } );
    return resources;

}

function disposeGarmentResources( resources ) {

    for ( const collection of Object.values( resources ) ) {

        for ( const resource of collection ) resource.dispose();
        collection.clear();

    }

}
