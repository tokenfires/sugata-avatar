import assert from 'node:assert/strict';
import {existingTargets,targetDescriptor,readExistingBoundaries} from './read-targets.mjs';
let groups=0;
async function test(name,fn){await fn();groups++;console.log('PASS '+name);}
function fixture({sharpen=false}={}) {
 const records=new WeakMap(),targets=[],backend={has:q=>records.has(q),get:q=>records.get(q)};
 const target=name=>{const texture={isTexture:true,name,type:1016,format:1023,colorSpace:'',flipY:false};const t={isRenderTarget:true,width:2,height:2,samples:0,textures:[texture]};
  records.set(texture,{texture:{width:2,height:2,depthOrArrayLayers:1,format:'rgba16float',mipLevelCount:1,sampleCount:1,usage:17},textureDescriptorGPU:{format:'rgba16float',mipLevelCount:1,sampleCount:1}});targets.push(t);return t;};
 const scene=target('output'),textures={output:scene.textures[0]};for(const name of['diffuseColor','normal','velocity','sssMask']){const t=target(name);textures[name]=t.textures[0];scene.textures.push(t.textures[0]);}
 const temporal={isTAAUNode:true,_resolveRenderTarget:target('resolve'),_historyRenderTarget:target('history')};
 const bloom={inputNode:{renderTarget:target('composite')},_renderTargetsHorizontal:[target('bloom-h')],_renderTargetsVertical:[target('bloom-v')]};
 const matrix={toArray:()=>[1,0,0,0,1,0,0,0,1]};let calls=0;
 const renderer={backend,_nodes:{nodeFrame:{frameId:1000065,renderId:42,time:0,deltaTime:0}},info:{frame:65,render:{drawCalls:10,triangles:99}},_animation:{getAnimationLoop:()=>null},getRenderTarget:()=>null,
  async readRenderTargetPixelsAsync(t,x,y,w,h,index,face){calls++;assert.deepEqual([x,y,w,h,face],[0,0,2,2,0]);assert.ok(t.textures[index]);return new Uint16Array(136).fill(0x3c00);}};
 const stage={backendName:'webgpu',renderer,scenePass:{renderTarget:scene},gbuffer:{pass:{renderTarget:scene},textures},camera:{matrixWorld:matrix,projectionMatrix:matrix,matrixWorldInverse:matrix},grade:{bloomNode:bloom},ambientOcclusion:{occlusion:{_target:target('ao')}},
 temporal:{mode:'taau',node:{passNode:temporal},sharpenNode:sharpen?{textureNode:{isRTTNode:true,node:temporal},_renderTarget:target('sharpen')}:null,frameEpoch:()=>({jitterIndex:3,historyWidth:2})}};
 return {avatar:{stage,clockSeconds:0},renderer,records,targets,calls:()=>calls};
}
await test('Reads actual owned targets serially without render methods or state mutation',async()=>{
 for(const sharpen of[false,true]){const f=fixture({sharpen}),saved=[];let saving=false;const r=await readExistingBoundaries(f.avatar,async(m,b)=>{assert.equal(saving,false);saving=true;await Promise.resolve();const bytes=Buffer.from(b,'base64');assert.equal(bytes.length,272);saved.push(m);saving=false;});assert.equal(r.records.length,sharpen?11:10);assert.equal(f.calls(),r.records.length);assert.equal(saved.length,r.records.length);assert.deepEqual(r.before,r.after);assert.equal(r.allCountersAndTargetOwnersUnchanged,true);}
});
await test('Missing or aliased targets fail before reading',()=>{
 const f=fixture();f.avatar.stage.grade.bloomNode.inputNode.renderTarget=null;assert.throws(()=>existingTargets(f.avatar.stage));assert.equal(f.calls(),0);
 const g=fixture();g.avatar.stage.grade.bloomNode._renderTargetsVertical[0]=g.avatar.stage.grade.bloomNode._renderTargetsHorizontal[0];assert.throws(()=>existingTargets(g.avatar.stage));assert.equal(g.calls(),0);
});
await test('Native upload, dimensions, sample count, mip, usage and format are required',()=>{
 for(const kind of['upload','size','sample','mip','usage','format']){const f=fixture(),q=existingTargets(f.avatar.stage)[0],d=f.records.get(q.target.textures[q.index]);if(kind==='upload')f.records.delete(q.target.textures[q.index]);if(kind==='size')d.texture.width=4;if(kind==='sample')d.textureDescriptorGPU.sampleCount=4;if(kind==='mip')d.textureDescriptorGPU.mipLevelCount=2;if(kind==='usage')d.texture.usage=16;if(kind==='format')d.texture.format='rgba8unorm';assert.throws(()=>targetDescriptor(f.renderer,q));assert.equal(f.calls(),0);}
});
await test('A changed motion clock fails and does not read a second target',async()=>{
 const f=fixture();await assert.rejects(readExistingBoundaries(f.avatar,async()=>{f.avatar.clockSeconds=1;}),/counters changed/);assert.equal(f.calls(),1);
});
await test('Foreign GPU storage and descriptor change at end fail',async()=>{
 for(const change of['identity','descriptor']){const f=fixture();let n=0;await assert.rejects(readExistingBoundaries(f.avatar,async()=>{if(++n===10){const q=existingTargets(f.avatar.stage)[0],d=f.records.get(q.target.textures[q.index]);if(change==='identity')d.texture={...d.texture};else q.target.textures[q.index].flipY=true;}}),change==='identity'?/texture owner changed/:/descriptor changed/);}
});
await test('GPU readback rejection and evidence-sink failure propagate with no retry',async()=>{
 const f=fixture(),e=new Error('native copy failed');f.renderer.readRenderTargetPixelsAsync=()=>Promise.reject(e);await assert.rejects(readExistingBoundaries(f.avatar,async()=>{}),q=>q===e);
 const g=fixture();await assert.rejects(readExistingBoundaries(g.avatar,async()=>{throw e;}),q=>q===e);assert.equal(g.calls(),1);
});
await test('Unread target storage cannot be changed by the evidence sink',async()=>{
 const f=fixture();await assert.rejects(readExistingBoundaries(f.avatar,async()=>{const q=existingTargets(f.avatar.stage)[1],d=f.records.get(q.target.textures[q.index]);d.texture={...d.texture};}),/texture owner changed/);assert.equal(f.calls(),1);
});
await test('Negative zero is preserved and nonfinite counters are rejected',async()=>{
 const f=fixture();await assert.rejects(readExistingBoundaries(f.avatar,async()=>{f.avatar.clockSeconds=-0;}),/counters changed/);assert.equal(f.calls(),1);
 const g=fixture();g.avatar.clockSeconds=NaN;await assert.rejects(readExistingBoundaries(g.avatar,async()=>{}),/Nonfinite/);assert.equal(g.calls(),0);
});
await test('Actual Three temporal/sharpen construction owns the asserted RTT chain',async()=>{
 const {PerspectiveCamera,Scene}=await import('three/webgpu');
 const {pass}=await import('three/tsl');
 const {GBuffer}=await import('../../../../packages/core/src/render/GBuffer.js');
 const {createTemporalResolve}=await import('../../../../packages/core/src/render/TRAAPost.js');
 for(const sharpness of[null,.4]) {
  const camera=new PerspectiveCamera(),gbuffer=new GBuffer(pass(new Scene(),camera)),temporal=createTemporalResolve({mode:'taau',gbuffer,camera,sharpness});
  const actual=sharpness===null?temporal.node.passNode:temporal.sharpenNode.textureNode.node;
  assert.equal(actual.isTAAUNode,true);
  if(sharpness!==null){assert.equal(temporal.sharpenNode.textureNode.isRTTNode,true);assert.equal(temporal.node.passNode,temporal.sharpenNode);}
  assert.equal(actual._resolveRenderTarget.texture,actual.getTextureNode().value);
  temporal.dispose();gbuffer.pass.dispose();
 }
});
console.log(JSON.stringify({groups,passed:true}));
